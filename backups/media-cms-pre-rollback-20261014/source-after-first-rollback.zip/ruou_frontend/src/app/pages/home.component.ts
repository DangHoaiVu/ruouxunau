import { Component, OnInit, inject } from '@angular/core';
import { RouterLink } from '@angular/router';
import { CatalogService } from '../core/catalog.service';
import { ContentService } from '../core/content.service';
import { ProductCardComponent } from '../shared/product-card.component';

@Component({
  selector: 'app-home',
  imports: [RouterLink, ProductCardComponent],
  template: `
    <section class="hero"><div class="hero-overlay"></div><div class="hero-content container reveal"><p class="eyebrow light">Từ miền đất võ Bình Định</p><h1>Giọt nồng kể chuyện quê.</h1><p>Rượu thủ công từ hạt gạo Việt, gìn giữ bằng bàn tay người thợ và được kể lại trong một dáng hình đương đại.</p><div class="hero-actions"><a class="button button-primary" routerLink="/san-pham">Khám phá bộ sưu tập</a><a class="button button-ghost" routerLink="/cau-chuyen">Đọc chuyện làng nghề</a></div></div><a class="scroll-cue" href="#featured">Cuộn để khám phá <span>↓</span></a></section>
    <section class="intro section container"><div><p class="eyebrow">Một thức quà từ Xứ Nẫu</p><h2 class="display-title">Không chỉ là vị rượu.<br />Đó là ký ức của một miền đất.</h2></div><div class="intro-copy"><p>Sản phẩm và bài viết được công bố từ Catalog và CMS của hệ thống.</p><a class="arrow-link" routerLink="/cau-chuyen">Xem những câu chuyện đã xuất bản <span>→</span></a></div></section>
    <section id="featured" class="section featured-section"><div class="container section-heading"><div><p class="eyebrow">Bộ sưu tập</p><h2>Chọn một hương vị riêng</h2></div><a class="arrow-link" routerLink="/san-pham">Xem tất cả <span>→</span></a></div>
      @if (catalog.loading()) { <div class="container loading-state">Đang tải sản phẩm…</div> } @else if (catalog.error()) { <div class="container empty-state error-state"><p>{{ catalog.error() }}</p><button class="button button-secondary" type="button" (click)="catalog.load()">Thử lại</button></div> } @else if (catalog.featuredProducts().length) { <div class="product-marquee" [class.static-list]="catalog.featuredProducts().length < 5"><div class="marquee-track">@for (product of catalog.featuredProducts(); track product.id) { <app-product-card [product]="product" /> }</div></div> } @else { <div class="container empty-state"><h3>Chưa có sản phẩm đã công bố</h3><p>Sản phẩm sẽ xuất hiện sau khi quản trị viên hoàn tất Catalog.</p></div> }
    </section>
    <section class="section stories-preview container"><div class="section-heading"><div><p class="eyebrow">Tạp chí Xứ Nẫu</p><h2>Chuyện bên ché rượu</h2></div><a class="arrow-link" routerLink="/cau-chuyen">Đọc tất cả <span>→</span></a></div>
      @if (content.loading()) { <div class="loading-state">Đang tải bài viết…</div> } @else if (content.error()) { <div class="empty-state error-state"><p>{{ content.error() }}</p><button class="button button-secondary" type="button" (click)="content.load()">Thử lại</button></div> } @else { <div class="story-marquee"><div class="story-track">@for (story of content.stories().slice(0, 8); track story.id) { <article class="story-card"><a [routerLink]="['/cau-chuyen', story.slug]">@if (story.featuredMedia?.url) { <img [src]="story.featuredMedia!.url" [alt]="story.featuredMedia!.altText || story.title" loading="lazy" /> } @else { <span class="image-placeholder">Tạp chí Xứ Nẫu</span> }</a><p class="eyebrow">{{ story.category.name }}</p><h3><a [routerLink]="['/cau-chuyen', story.slug]">{{ story.title }}</a></h3><p>{{ story.excerpt }}</p></article> } @empty { <div class="empty-state"><h3>Chưa có bài viết đã xuất bản</h3></div> }</div></div> }
    </section>
  `,
})
export class HomeComponent implements OnInit {
  readonly catalog = inject(CatalogService);
  readonly content = inject(ContentService);
  ngOnInit(): void { this.catalog.load(); this.content.load(); }
}
