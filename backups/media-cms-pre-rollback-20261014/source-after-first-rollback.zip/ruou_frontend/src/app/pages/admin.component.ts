import { HttpClient } from '@angular/common/http';
import { Component, OnInit, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { forkJoin } from 'rxjs';
import { apiErrorMessage } from '../core/api-error';
import { AuthService } from '../core/auth.service';
import { ApiPage, Product, Story } from '../core/models';
import { StoreService } from '../core/store.service';

type SectionId = 'dashboard' | 'products' | 'articles' | 'commerce';
interface MediaItem { id: string; url: string; altText: string; }

@Component({
  selector: 'app-admin', imports: [FormsModule, RouterLink],
  template: `
    <section class="admin-shell"><aside class="admin-sidebar"><div class="admin-brand"><span>BĐ</span><strong>Quản trị Xứ Nẫu</strong></div><nav>@for (section of sections; track section.id) { <button type="button" [class.active]="activeSection() === section.id" (click)="activeSection.set(section.id)"><span aria-hidden="true">{{ section.icon }}</span><span>{{ section.label }}</span></button> }</nav><a class="admin-storefront-link" routerLink="/">← Xem website</a></aside>
      <main class="admin-main"><header><div><p class="eyebrow">Media/CMS</p><h1>{{ currentSection().label }}</h1><p class="admin-subtitle">{{ currentSection().description }}</p></div><div class="admin-user"><span>{{ initials() }}</span><div><strong>{{ auth.user()?.fullName }}</strong><small>{{ (auth.user()?.roles ?? []).join(', ') }}</small></div></div></header>
        @if (loading()) { <div class="loading-state">Đang đồng bộ dữ liệu quản trị…</div> }
        @if (error()) { <div class="admin-alert error-state" role="alert">{{ error() }} <button type="button" (click)="loadAll()">Thử lại</button></div> }
        @if (activeSection() === 'dashboard') { <div class="admin-alert">Số liệu đọc trực tiếp từ API/MySQL tại baseline Media/CMS (V1–V5).</div><div class="metric-grid"><button type="button" (click)="activeSection.set('products')"><span>Sản phẩm</span><strong>{{ products().length }}</strong><small>Catalog</small></button><button type="button" (click)="activeSection.set('articles')"><span>Bài viết</span><strong>{{ articles().length }}</strong><small>{{ publishedArticleCount() }} bài đã xuất bản</small></button><div><span>Media</span><strong>{{ mediaCount() }}</strong><small>Ảnh đã đăng ký</small></div></div><section class="management-panel module-summary"><h2>Trạng thái baseline</h2><p>Identity, RBAC, Catalog, Media và CMS đã có API thật. Kho, giỏ hàng, đơn hàng, VNPay, vận chuyển và Site Content chưa thuộc milestone này.</p><button class="button button-secondary" type="button" (click)="loadAll()">Đồng bộ lại dữ liệu</button></section> }
        @if (activeSection() === 'products') { <section class="management-panel"><div class="management-toolbar"><label><span>⌕</span><input [(ngModel)]="search" placeholder="Tìm sản phẩm" /></label></div><div class="table-wrap"><table><thead><tr><th>Sản phẩm</th><th>Danh mục</th><th>Biến thể</th><th>Giá từ</th><th>Trạng thái</th><th></th></tr></thead><tbody>@for (product of filteredProducts(); track product.id) { <tr><td><strong>{{ product.name }}</strong><small>{{ product.slug }}</small></td><td>{{ product.category.name }}</td><td>{{ product.variantCount }}</td><td>{{ store.formatPrice(product.minPrice) }}</td><td><span class="status" [class.paid]="product.status === 'ACTIVE'">{{ statusLabel(product.status) }}</span></td><td><a class="table-action" [routerLink]="['/san-pham', product.slug]">Xem công khai</a></td></tr> } @empty { <tr><td colspan="6">Chưa có dữ liệu sản phẩm.</td></tr> }</tbody></table></div></section> }
        @if (activeSection() === 'articles') { <section class="management-panel"><div class="management-toolbar"><label><span>⌕</span><input [(ngModel)]="search" placeholder="Tìm bài viết" /></label></div><div class="table-wrap"><table><thead><tr><th>Bài viết</th><th>Chuyên mục</th><th>Tác giả</th><th>Trạng thái</th></tr></thead><tbody>@for (article of filteredArticles(); track article.id) { <tr><td><strong>{{ article.title }}</strong><small>{{ article.slug }}</small></td><td>{{ article.category.name }}</td><td>{{ article.authorName }}</td><td><span class="status" [class.paid]="article.status === 'PUBLISHED'">{{ statusLabel(article.status) }}</span></td></tr> } @empty { <tr><td colspan="4">Chưa có dữ liệu bài viết.</td></tr> }</tbody></table></div></section> }
        @if (activeSection() === 'commerce') { <section class="management-panel"><div class="locked-modules">@for (module of commerceModules; track module.name) { <article><span>Chưa triển khai</span><h3>{{ module.name }}</h3><p>{{ module.reason }}</p><button type="button" disabled>{{ module.milestone }}</button></article> }</div></section> }
      </main>
    </section>
  `,
})
export class AdminComponent implements OnInit {
  readonly auth = inject(AuthService); readonly store = inject(StoreService); private readonly http = inject(HttpClient);
  readonly activeSection = signal<SectionId>('dashboard'); readonly loading = signal(false); readonly error = signal(''); readonly products = signal<Product[]>([]); readonly articles = signal<Story[]>([]); readonly mediaCount = signal(0); search = '';
  readonly sections = [{ id: 'dashboard' as const, label: 'Tổng quan', icon: '⌂', description: 'Theo dõi dữ liệu thật tại MySQL.' }, { id: 'products' as const, label: 'Sản phẩm', icon: '▣', description: 'Danh sách Catalog.' }, { id: 'articles' as const, label: 'Bài viết', icon: '¶', description: 'Nội dung CMS và trạng thái xuất bản.' }, { id: 'commerce' as const, label: 'Thương mại', icon: '₫', description: 'Các module sẽ làm ở milestone tiếp theo.' }];
  readonly commerceModules = [{ name: 'Kho và lô sản xuất', milestone: 'M3', reason: 'Cần reservation nguyên tử và chống tồn âm.' }, { name: 'Giỏ hàng và khuyến mãi', milestone: 'M4', reason: 'Không dùng localStorage làm nguồn nghiệp vụ.' }, { name: 'Đơn hàng và chuyển khoản', milestone: 'M5', reason: 'Đơn hàng cần state machine.' }, { name: 'VNPay và vận chuyển', milestone: 'M6–M7', reason: 'Cần xác thực callback và adapter thật.' }];
  ngOnInit(): void { this.loadAll(); }
  currentSection() { return this.sections.find(item => item.id === this.activeSection()) ?? this.sections[0]; }
  initials(): string { return (this.auth.user()?.fullName ?? 'Admin').split(/\s+/).slice(-2).map(item => item[0]).join('').toUpperCase(); }
  loadAll(): void { this.loading.set(true); this.error.set(''); forkJoin({ products: this.http.get<ApiPage<Product>>('/api/v1/admin/products', { params: { page: 0, size: 100 } }), articles: this.http.get<ApiPage<Story>>('/api/v1/admin/articles', { params: { page: 0, size: 100 } }), media: this.http.get<ApiPage<MediaItem>>('/api/v1/admin/media', { params: { page: 0, size: 100 } }) }).subscribe({ next: value => { this.products.set(value.products.items); this.articles.set(value.articles.items); this.mediaCount.set(value.media.totalElements); this.loading.set(false); }, error: error => { this.error.set(apiErrorMessage(error, 'Không tải được dữ liệu quản trị.')); this.loading.set(false); } }); }
  publishedArticleCount(): number { return this.articles().filter(item => item.status === 'PUBLISHED').length; }
  filteredProducts() { const q = this.search.toLowerCase(); return this.products().filter(item => !q || `${item.name} ${item.slug}`.toLowerCase().includes(q)); }
  filteredArticles() { const q = this.search.toLowerCase(); return this.articles().filter(item => !q || `${item.title} ${item.slug}`.toLowerCase().includes(q)); }
  statusLabel(status: string): string { return ({ ACTIVE: 'Công khai', INACTIVE: 'Ngừng công khai', DRAFT: 'Bản nháp', PUBLISHED: 'Đã xuất bản', REVIEW: 'Chờ duyệt', ARCHIVED: 'Lưu trữ' } as Record<string, string>)[status] ?? status; }
}
