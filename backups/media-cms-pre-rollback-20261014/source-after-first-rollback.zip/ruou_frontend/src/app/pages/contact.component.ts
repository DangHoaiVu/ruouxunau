import { Component } from '@angular/core';

@Component({
  selector: 'app-contact',
  template: `
    <section class="page-hero compact contact-hero"><div class="container"><p class="eyebrow light">Kết nối với Xứ Nẫu</p><h1>Ghé thăm,<br /><em>trò chuyện cùng chúng tôi.</em></h1></div></section>
    <section class="section container contact-grid"><div><p class="eyebrow">Thông tin liên hệ</p><h2>Chúng tôi luôn sẵn lòng lắng nghe.</h2><div class="empty-state compact"><h3>Thông tin đang được cập nhật</h3><p>Thông tin doanh nghiệp, mạng xã hội và bản đồ sẽ được bổ sung ở milestone nội dung website.</p></div></div><div class="map-panel"><div class="map-consent"><span aria-hidden="true">⌖</span><h3>Bản đồ chưa được công bố</h3><p>Vị trí chính thức sẽ được cấu hình khi module Site Content được triển khai trở lại.</p></div></div></section>
  `,
})
export class ContactComponent {}
