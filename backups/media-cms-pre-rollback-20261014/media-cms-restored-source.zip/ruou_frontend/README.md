# Rượu Xứ Nẫu — Angular storefront

Website thương mại điện tử kết hợp tạp chí/CMS cho sản phẩm rượu truyền thống Bình Định.

## Chạy dự án

```bash
npm install
npm start
```

Mở `http://localhost:4200`.

## Chức năng đã có

- Xác nhận người dùng đủ 18 tuổi.
- Trang chủ thương hiệu, light/dark mode và responsive.
- Danh sách sản phẩm có tìm kiếm, lọc, sắp xếp.
- Chi tiết sản phẩm, tồn kho và sản phẩm liên quan.
- Bắt buộc đăng nhập trước khi thêm giỏ hàng.
- Giỏ hàng, mã ưu đãi demo `RUOUBD10` và checkout.
- Lựa chọn GHN, GHTK hoặc Viettel Post.
- Lựa chọn COD, chuyển khoản hoặc VNPay.
- Trang câu chuyện, danh sách bài viết và trang đọc bài.
- Trang tài khoản và dashboard quản trị tách riêng.
- Dữ liệu giỏ hàng, tài khoản, theme và xác nhận tuổi được lưu cục bộ.

## Tài khoản demo

- Nhập email bất kỳ và mật khẩu từ 6 ký tự để đăng nhập khách hàng.
- Email có chứa từ `admin` sẽ mở vai trò quản trị giao diện.

Đây chỉ là xác thực phía trình duyệt để kiểm thử UI. Trước khi vận hành thật phải thay bằng JWT/session và phân quyền từ Spring Boot.

## Thay ảnh và dữ liệu mẫu

Sản phẩm, bài viết và toàn bộ URL ảnh mẫu nằm trong `src/app/core/mock-data.ts`. Chỉ cần đổi các URL trong file này khi có bộ ảnh chính thức.

## Tích hợp production còn cần thực hiện

- API Spring Boot và MySQL.
- JWT, refresh token và RBAC.
- VNPay sandbox/production và xác thực webhook.
- API báo phí, tạo vận đơn và webhook trạng thái từ GHN/GHTK/Viettel Post.
- Object storage cho media CMS.
- CMS admin, tồn kho, đơn hàng và audit log lưu trên database.

## Kiểm tra

```bash
npm run build
npm test -- --watch=false
```
