import { Component, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { StoreService } from '../core/store.service';

@Component({
  selector: 'app-auth', imports: [FormsModule, RouterLink],
  template: `
    <section class="auth-page"><div class="auth-visual"><div><p class="eyebrow light">Thành viên Xứ Nẫu</p><h1>Mỗi chai rượu,<br /><em>một câu chuyện.</em></h1><p>Đăng nhập để mua hàng, theo dõi đơn và lưu những hương vị bạn yêu thích.</p></div></div>
      <div class="auth-form-wrap"><form class="auth-form" (ngSubmit)="submit()"><a class="back-link" routerLink="/">← Về trang chủ</a>
        @if (mode() === 'login') {
          <p class="eyebrow">Chào mừng trở lại</p><h2>Đăng nhập</h2><p class="muted">Bạn cần đăng nhập trước khi thêm sản phẩm vào giỏ.</p>
        } @else if (mode() === 'register') {
          <p class="eyebrow">Thành viên mới</p><h2>Tạo tài khoản</h2><p class="muted">Tài khoản demo được lưu cục bộ trên trình duyệt này.</p><label>Họ và tên<input name="name" [(ngModel)]="name" required placeholder="Nguyễn Văn A" /></label>
        } @else {
          <p class="eyebrow">Khôi phục truy cập</p><h2>Quên mật khẩu</h2><p class="muted">Nhập email để mô phỏng yêu cầu đặt lại mật khẩu.</p>
        }
        <label>Email<input type="email" name="email" [(ngModel)]="email" required placeholder="ban@example.com" /></label>
        @if (mode() !== 'forgot') { <label>Mật khẩu<span><input [type]="showPassword() ? 'text' : 'password'" name="password" [(ngModel)]="password" required minlength="6" placeholder="Tối thiểu 6 ký tự" /><button type="button" (click)="showPassword.set(!showPassword())">{{ showPassword() ? 'Ẩn' : 'Hiện' }}</button></span></label> }
        @if (mode() === 'login') { <div class="form-options"><label class="check-row"><input type="checkbox" /> Ghi nhớ đăng nhập</label><button type="button" class="link-button" (click)="mode.set('forgot')">Quên mật khẩu?</button></div> }
        <button class="button button-primary full" type="submit">{{ mode() === 'login' ? 'Đăng nhập' : mode() === 'register' ? 'Tạo tài khoản' : 'Gửi yêu cầu' }}</button>
        <p class="auth-switch">@if (mode() === 'login') { Chưa có tài khoản? <button type="button" (click)="mode.set('register')">Đăng ký ngay</button> } @else { Đã có tài khoản? <button type="button" (click)="mode.set('login')">Quay lại đăng nhập</button> }</p>
        <small class="demo-note">Bản demo: dùng email bất kỳ và mật khẩu từ 6 ký tự. Email chứa “admin” mở quyền quản trị giao diện.</small>
      </form></div>
    </section>
  `,
})
export class AuthComponent {
  readonly store = inject(StoreService); private readonly router = inject(Router); private readonly route = inject(ActivatedRoute);
  readonly showPassword = signal(false); readonly mode = signal<'login' | 'register' | 'forgot'>('login');
  name = ''; email = ''; password = '';
  submit(): void {
    if (!this.email || (this.mode() !== 'forgot' && this.password.length < 6) || (this.mode() === 'register' && !this.name)) { this.store.notify('Vui lòng nhập thông tin hợp lệ'); return; }
    if (this.mode() === 'forgot') { this.store.notify('Đã ghi nhận yêu cầu đặt lại mật khẩu ở chế độ demo'); this.mode.set('login'); return; }
    this.store.login(this.email, this.mode() === 'register' ? this.name : undefined); this.router.navigateByUrl(this.route.snapshot.queryParamMap.get('returnUrl') ?? '/tai-khoan');
  }
}
