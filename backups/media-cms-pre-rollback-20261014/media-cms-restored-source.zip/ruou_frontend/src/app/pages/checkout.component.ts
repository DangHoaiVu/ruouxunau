import { Component, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { StoreService } from '../core/store.service';

@Component({
  selector: 'app-checkout', imports: [FormsModule, RouterLink],
  template: `
    <section class="checkout-page section container"><div class="checkout-head"><a routerLink="/gio-hang">← Quay lại giỏ hàng</a><div class="checkout-steps"><span class="active">1. Thông tin</span><i></i><span>2. Xác nhận</span><i></i><span>3. Hoàn tất</span></div></div>
      @if (!completed()) { <div class="checkout-layout"><form class="checkout-form" (ngSubmit)="placeOrder()"><section><div class="form-section-title"><span>01</span><div><h2>Thông tin nhận hàng</h2><p>Đơn vị vận chuyển sẽ liên hệ theo thông tin này.</p></div></div><div class="form-grid"><label>Họ và tên<input name="name" [(ngModel)]="name" required /></label><label>Số điện thoại<input name="phone" [(ngModel)]="phone" required pattern="[0-9]{9,11}" /></label><label class="full-span">Địa chỉ cụ thể<input name="address" [(ngModel)]="address" required placeholder="Số nhà, đường, phường/xã..." /></label><label>Tỉnh/thành<select name="province" [(ngModel)]="province" required><option value="">Chọn tỉnh/thành</option><option>Bình Định</option><option>TP. Hồ Chí Minh</option><option>Hà Nội</option><option>Đà Nẵng</option></select></label><label>Ghi chú<input name="note" [(ngModel)]="note" placeholder="Thời gian giao phù hợp..." /></label></div></section>
      <section><div class="form-section-title"><span>02</span><div><h2>Đơn vị vận chuyển</h2><p>Phí và thời gian đang là dữ liệu demo từ điểm tích hợp.</p></div></div><div class="option-list">@for (shipping of shippingOptions; track shipping.id) { <label class="select-card" [class.selected]="selectedShipping === shipping.id"><input type="radio" name="shipping" [value]="shipping.id" [(ngModel)]="selectedShipping" /><span class="provider-logo">{{ shipping.logo }}</span><span><strong>{{ shipping.name }}</strong><small>{{ shipping.time }}</small></span><b>{{ store.formatPrice(shipping.fee) }}</b></label> }</div></section>
      <section><div class="form-section-title"><span>03</span><div><h2>Phương thức thanh toán</h2><p>Chọn một phương thức phù hợp với bạn.</p></div></div><div class="option-list payment-options"><label class="select-card" [class.selected]="payment === 'cod'"><input type="radio" name="payment" value="cod" [(ngModel)]="payment" /><span class="provider-logo">₫</span><span><strong>Thanh toán khi nhận hàng</strong><small>Thanh toán trực tiếp cho người giao hàng</small></span></label><label class="select-card" [class.selected]="payment === 'bank'"><input type="radio" name="payment" value="bank" [(ngModel)]="payment" /><span class="provider-logo">↗</span><span><strong>Chuyển khoản ngân hàng</strong><small>Thông tin tài khoản hiển thị sau khi đặt đơn</small></span></label><label class="select-card" [class.selected]="payment === 'vnpay'"><input type="radio" name="payment" value="vnpay" [(ngModel)]="payment" /><span class="provider-logo vnpay">VNP</span><span><strong>VNPay</strong><small>Thẻ ATM, Visa/Mastercard hoặc QR</small></span></label></div></section>
      <label class="check-row legal-check"><input type="checkbox" name="age" [(ngModel)]="confirmedAge" required /> Tôi xác nhận người nhận hàng từ đủ 18 tuổi và đồng ý với điều khoản mua bán.</label><button class="button button-primary full" type="submit">Đặt hàng · {{ store.formatPrice(grandTotal()) }}</button></form>
      <aside class="order-summary checkout-summary"><h2>Đơn hàng của bạn</h2>@for (item of store.cart(); track item.product.id) { <div class="checkout-item"><img [src]="item.product.image" [alt]="item.product.name" /><span><strong>{{ item.product.name }}</strong><small>{{ item.quantity }} × {{ store.formatPrice(item.product.price) }}</small></span></div> }<dl><div><dt>Tạm tính</dt><dd>{{ store.formatPrice(store.subtotal()) }}</dd></div>@if (store.discount() > 0) { <div><dt>Ưu đãi RUOUBD10</dt><dd>− {{ store.formatPrice(store.discount()) }}</dd></div> }<div><dt>Vận chuyển</dt><dd>{{ store.formatPrice(shippingFee()) }}</dd></div><div class="summary-total"><dt>Tổng thanh toán</dt><dd>{{ store.formatPrice(grandTotal()) }}</dd></div></dl><div class="secure-note">✓ Thanh toán được bảo vệ. VNPay chỉ chuyển trạng thái đã thanh toán sau khi backend xác thực webhook.</div></aside></div> }
      @else { <div class="success-card"><span>✓</span><p class="eyebrow">Đặt hàng thành công</p><h1>Cảm ơn bạn đã chọn<br />hương vị Xứ Nẫu.</h1><p>Mã đơn hàng: <strong>RXN-{{ orderCode }}</strong></p><p>{{ successMessage }}</p><div><a class="button button-primary" routerLink="/tai-khoan">Theo dõi đơn hàng</a><a class="button button-secondary" routerLink="/">Về trang chủ</a></div></div> }
    </section>
  `,
})
export class CheckoutComponent {
  readonly store = inject(StoreService); private readonly router = inject(Router); readonly completed = signal(false);
  name = ''; phone = ''; address = ''; province = ''; note = ''; selectedShipping = 'ghn'; payment = 'cod'; confirmedAge = false; orderCode = ''; successMessage = '';
  readonly shippingOptions = [{ id: 'ghn', logo: 'GHN', name: 'Giao Hàng Nhanh', time: 'Dự kiến 2–3 ngày', fee: 32000 }, { id: 'ghtk', logo: 'GHTK', name: 'Giao Hàng Tiết Kiệm', time: 'Dự kiến 3–5 ngày', fee: 26000 }, { id: 'viettel', logo: 'VT', name: 'Viettel Post', time: 'Dự kiến 2–4 ngày', fee: 30000 }];
  ngOnInit(): void { if (!this.store.cart().length) this.router.navigateByUrl('/gio-hang'); }
  shippingFee(): number { return this.shippingOptions.find(item => item.id === this.selectedShipping)?.fee ?? 0; }
  grandTotal(): number { return this.store.subtotal() - this.store.discount() + this.shippingFee(); }
  placeOrder(): void {
    if (!this.name.trim() || !/^[0-9]{9,11}$/.test(this.phone) || !this.address.trim() || !this.province || !this.confirmedAge) { this.store.notify('Vui lòng điền đủ thông tin, số điện thoại hợp lệ và xác nhận độ tuổi'); return; }
    if (!this.store.cart().length) { this.router.navigateByUrl('/san-pham'); return; }
    this.orderCode = `${Date.now().toString().slice(-6)}`;
    const paymentMethod = this.payment === 'vnpay' ? 'VNPAY' : this.payment === 'bank' ? 'BANK_TRANSFER' : 'COD';
    const status = paymentMethod === 'COD' ? 'CONFIRMED' : 'PENDING_PAYMENT';
    const itemCount = this.store.cartCount();
    const total = this.grandTotal();
    const shippingProvider = this.shippingOptions.find(item => item.id === this.selectedShipping)?.name ?? this.selectedShipping;
    this.store.createOrder({ id: `RXN-${this.orderCode}`, createdAt: new Date().toLocaleDateString('vi-VN'), itemCount, total, paymentMethod, shippingProvider, status });
    this.successMessage = paymentMethod === 'VNPAY' ? 'Đơn đang chờ thanh toán. Bản production sẽ chuyển sang VNPay và chỉ cập nhật sau khi webhook hợp lệ.' : paymentMethod === 'BANK_TRANSFER' ? 'Đơn đang chờ chuyển khoản. Thông tin tài khoản sẽ được backend cung cấp theo mã đơn.' : 'Đơn COD đã được xác nhận ở chế độ demo.';
    this.completed.set(true); window.scrollTo({ top: 0, behavior: 'smooth' });
  }
}
