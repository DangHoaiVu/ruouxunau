import { Component, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { StoreService } from '../core/store.service';

type AdminSection = { id: string; label: string; icon: string; description: string; action: string };

@Component({
  selector: 'app-admin', imports: [FormsModule, RouterLink],
  template: `
    <section class="admin-shell">
      <aside class="admin-sidebar"><div class="admin-brand"><span>BĐ</span><strong>Quản trị Xứ Nẫu</strong></div><nav>@for (section of sections; track section.id) { <button type="button" [class.active]="activeSection() === section.id" (click)="selectSection(section.id)">{{ section.icon }} <span>{{ section.label }}</span></button> }</nav><a class="admin-storefront-link" routerLink="/">← Xem website</a></aside>
      <main class="admin-main">
        <header><div><p class="eyebrow">{{ currentDate }}</p><h1>{{ currentSection().label }}</h1><p class="admin-subtitle">{{ currentSection().description }}</p></div><div class="admin-user"><span>QA</span><div><strong>{{ store.user()?.name }}</strong><small>Super Admin</small></div></div></header>

        @if (activeSection() === 'dashboard') {
          <div class="admin-alert">Dữ liệu dưới đây là dữ liệu minh họa. Mọi thao tác đều có phản hồi và đã sẵn cấu trúc để kết nối API Spring Boot.</div>
          <div class="metric-grid"><button type="button" (click)="selectSection('orders')"><span>Doanh thu hôm nay</span><strong>12.480.000₫</strong><small class="up">↑ 8,4% so với hôm qua</small></button><button type="button" (click)="selectSection('orders')"><span>Đơn hàng mới</span><strong>{{ 24 + store.orders().length }}</strong><small>6 đơn đang chờ xác nhận</small></button><button type="button" (click)="selectSection('inventory')"><span>Sản phẩm sắp hết</span><strong>3</strong><small class="warn">Cần nhập kho trong tuần</small></button><button type="button" (click)="selectSection('articles')"><span>Bài viết chờ đăng</span><strong>2</strong><small>Chỉ admin được xuất bản</small></button></div>
          <div class="admin-grid"><section class="admin-panel"><div class="panel-head"><div><h2>Đơn hàng gần đây</h2><p>Cập nhật theo thời gian thực</p></div><button type="button" (click)="selectSection('orders')">Xem tất cả</button></div><div class="table-wrap"><table><thead><tr><th>Mã đơn</th><th>Khách hàng</th><th>Thanh toán</th><th>Tổng tiền</th><th>Trạng thái</th><th></th></tr></thead><tbody>@for (order of recentOrders; track order.id) { <tr><td>#{{ order.id }}</td><td>{{ order.customer }}</td><td>{{ order.payment }}</td><td>{{ order.total }}</td><td><span class="status" [class]="'status ' + order.className">{{ order.status }}</span></td><td><button class="table-action" type="button" (click)="inspect('đơn hàng', order.id)">Xem</button></td></tr> }</tbody></table></div></section><section class="admin-panel stock-panel"><div class="panel-head"><div><h2>Cảnh báo kho</h2><p>Tồn khả dụng thấp</p></div><button type="button" (click)="selectSection('inventory')">Chi tiết</button></div>@for (product of store.products.slice(0, 3); track product.id) { <button type="button" class="stock-item" (click)="inspect('tồn kho', product.name)"><img [src]="product.image" [alt]="product.name" /><span><strong>{{ product.name }}</strong><small>SKU RXN-00{{ product.id }}</small></span><b>{{ product.stock }} chai</b></button> }</section></div>
        } @else {
          <section class="management-panel">
            <div class="management-toolbar"><label><span>⌕</span><input [(ngModel)]="search" [placeholder]="'Tìm trong ' + currentSection().label.toLowerCase()" /></label><button type="button" class="button button-primary" (click)="primaryAction()">+ {{ currentSection().action }}</button></div>

            @if (activeSection() === 'products') {
              <div class="table-wrap"><table><thead><tr><th>Sản phẩm</th><th>SKU</th><th>Giá</th><th>Tồn</th><th>Trạng thái</th><th></th></tr></thead><tbody>@for (product of filteredProducts(); track product.id) { <tr><td><div class="admin-product-cell"><img [src]="product.image" [alt]="product.name" /><strong>{{ product.name }}</strong></div></td><td>RXN-00{{ product.id }}</td><td>{{ store.formatPrice(product.price) }}</td><td>{{ product.stock }}</td><td><span class="status paid">Đang bán</span></td><td><button class="table-action" type="button" (click)="inspect('sản phẩm', product.name)">Chỉnh sửa</button></td></tr> }</tbody></table></div>
            } @else if (activeSection() === 'inventory') {
              <div class="inventory-grid">@for (product of filteredProducts(); track product.id) { <article><img [src]="product.image" [alt]="product.name" /><div><strong>{{ product.name }}</strong><small>RXN-00{{ product.id }}</small></div><dl><div><dt>Tồn thực tế</dt><dd>{{ product.stock }}</dd></div><div><dt>Đang giữ</dt><dd>{{ product.id % 3 }}</dd></div><div><dt>Khả dụng</dt><dd>{{ product.stock - (product.id % 3) }}</dd></div></dl><button type="button" (click)="inspect('lịch sử kho', product.name)">Xem lịch sử</button></article> }</div>
            } @else if (activeSection() === 'orders') {
              <div class="table-wrap"><table><thead><tr><th>Mã đơn</th><th>Khách hàng</th><th>Thanh toán</th><th>Tổng tiền</th><th>Trạng thái</th><th></th></tr></thead><tbody>@for (order of allOrders(); track order.id) { <tr><td>#{{ order.id }}</td><td>{{ order.customer }}</td><td>{{ order.payment }}</td><td>{{ order.total }}</td><td><span class="status" [class]="'status ' + order.className">{{ order.status }}</span></td><td><button class="table-action" type="button" (click)="inspect('đơn hàng', order.id)">Xử lý</button></td></tr> }</tbody></table></div>
            } @else if (activeSection() === 'articles') {
              <div class="table-wrap"><table><thead><tr><th>Bài viết</th><th>Chuyên mục</th><th>Tác giả</th><th>Ngày đăng</th><th>Trạng thái</th><th></th></tr></thead><tbody>@for (story of filteredStories(); track story.id) { <tr><td><strong>{{ story.title }}</strong></td><td>{{ story.category }}</td><td>{{ story.author }}</td><td>{{ story.publishedAt }}</td><td><span class="status paid">Đã xuất bản</span></td><td><button class="table-action" type="button" (click)="inspect('bài viết', story.title)">Chỉnh sửa</button></td></tr> }<tr><td><strong>Bí quyết giữ men qua mùa mưa</strong></td><td>Kỹ nghệ</td><td>Ban biên tập</td><td>—</td><td><span class="status pending">Bản nháp</span></td><td><button class="table-action publish" type="button" (click)="publishDraft()">Xuất bản</button></td></tr></tbody></table></div>
            } @else if (activeSection() === 'shipping') {
              <div class="provider-grid">@for (provider of providers; track provider.name) { <article><span>{{ provider.logo }}</span><div><h3>{{ provider.name }}</h3><p>{{ provider.description }}</p></div><em [class.connected]="provider.connected">{{ provider.connected ? 'Đã cấu hình demo' : 'Chưa kết nối' }}</em><button type="button" (click)="configure(provider.name)">Cấu hình</button></article> }</div>
            } @else if (activeSection() === 'payments') {
              <div class="provider-grid">@for (provider of payments; track provider.name) { <article><span>{{ provider.logo }}</span><div><h3>{{ provider.name }}</h3><p>{{ provider.description }}</p></div><em [class.connected]="provider.connected">{{ provider.connected ? 'Đang bật' : 'Chưa kết nối' }}</em><button type="button" (click)="configure(provider.name)">Cấu hình</button></article> }</div>
            } @else if (activeSection() === 'media') {
              <div class="media-grid">@for (product of store.products; track product.id) { <button type="button" (click)="inspect('ảnh', product.name)"><img [src]="product.image" [alt]="product.name" /><span>{{ product.name }}</span></button> }</div>
            } @else if (activeSection() === 'settings') {
              <div class="settings-list"><article><div><h3>Xác nhận độ tuổi</h3><p>Yêu cầu khách xác nhận đủ 18 tuổi khi truy cập.</p></div><button type="button" class="toggle" [class.active]="ageCheckEnabled()" [attr.aria-pressed]="ageCheckEnabled()" aria-label="Bật hoặc tắt xác nhận độ tuổi" (click)="toggleSetting('Xác nhận độ tuổi', ageCheckEnabled)"><span></span></button></article><article><div><h3>Cho phép COD</h3><p>Nhận thanh toán khi giao hàng.</p></div><button type="button" class="toggle" [class.active]="codEnabled()" [attr.aria-pressed]="codEnabled()" aria-label="Bật hoặc tắt thanh toán COD" (click)="toggleSetting('Thanh toán COD', codEnabled)"><span></span></button></article><article><div><h3>Chế độ bảo trì</h3><p>Tạm ẩn storefront với khách truy cập.</p></div><button type="button" class="toggle" [class.active]="maintenanceEnabled()" [attr.aria-pressed]="maintenanceEnabled()" aria-label="Bật hoặc tắt chế độ bảo trì" (click)="toggleSetting('Chế độ bảo trì', maintenanceEnabled)"><span></span></button></article></div>
            } @else {
              <div class="module-summary"><span>{{ currentSection().icon }}</span><h2>{{ currentSection().label }}</h2><p>{{ currentSection().description }}</p><div class="module-cards"><button type="button" (click)="primaryAction()"><strong>{{ summaryCount() }}</strong><small>Tổng bản ghi demo</small></button><button type="button" (click)="store.notify('Đã áp dụng bộ lọc demo')"><strong>0</strong><small>Cần xử lý</small></button><button type="button" (click)="store.notify('Dữ liệu sẽ đồng bộ khi kết nối API')"><strong>100%</strong><small>Trạng thái hệ thống</small></button></div></div>
            }
          </section>
        }
      </main>
    </section>
  `,
})
export class AdminComponent {
  readonly store = inject(StoreService); readonly activeSection = signal('dashboard'); search = '';
  readonly currentDate = new Intl.DateTimeFormat('vi-VN', { weekday: 'long', day: '2-digit', month: '2-digit', year: 'numeric' }).format(new Date());
  readonly ageCheckEnabled = signal(true); readonly codEnabled = signal(true); readonly maintenanceEnabled = signal(false);
  readonly sections: AdminSection[] = [
    { id: 'dashboard', label: 'Tổng quan', icon: '⌂', description: 'Theo dõi nhanh tình hình vận hành cửa hàng.', action: 'Tạo báo cáo' },
    { id: 'products', label: 'Sản phẩm', icon: '▣', description: 'Quản lý sản phẩm, biến thể, giá và trạng thái bán.', action: 'Thêm sản phẩm' },
    { id: 'categories', label: 'Danh mục', icon: '◫', description: 'Tổ chức các dòng rượu và nhóm sản phẩm.', action: 'Thêm danh mục' },
    { id: 'inventory', label: 'Kho hàng', icon: '⌁', description: 'Theo dõi tồn thực tế, tồn giữ và tồn khả dụng.', action: 'Nhập kho' },
    { id: 'batches', label: 'Lô sản xuất', icon: '□', description: 'Quản lý nguồn gốc, ngày nấu và hạn dùng từng lô.', action: 'Tạo lô' },
    { id: 'orders', label: 'Đơn hàng', icon: '▤', description: 'Xử lý đơn theo luồng trạng thái được kiểm soát.', action: 'Tạo đơn' },
    { id: 'payments', label: 'Thanh toán', icon: '₫', description: 'Đối soát COD, chuyển khoản và webhook VNPay.', action: 'Đối soát' },
    { id: 'shipping', label: 'Vận chuyển', icon: '↗', description: 'Cấu hình GHN, GHTK, Viettel Post và vận đơn.', action: 'Tạo vận đơn' },
    { id: 'customers', label: 'Khách hàng', icon: '♙', description: 'Quản lý hồ sơ, địa chỉ và lịch sử mua hàng.', action: 'Thêm khách hàng' },
    { id: 'promotions', label: 'Khuyến mãi', icon: '%', description: 'Quản lý mã giảm giá và điều kiện áp dụng.', action: 'Tạo khuyến mãi' },
    { id: 'articles', label: 'Bài viết', icon: '¶', description: 'Soạn thảo và xuất bản nội dung bởi admin.', action: 'Viết bài mới' },
    { id: 'media', label: 'Thư viện ảnh', icon: '▧', description: 'Quản lý ảnh, alt text và nơi đang sử dụng.', action: 'Tải ảnh lên' },
    { id: 'settings', label: 'Cấu hình', icon: '⚙', description: 'Thiết lập storefront và quy tắc vận hành.', action: 'Lưu cấu hình' },
  ];
  readonly recentOrders = [{ id: 'RXN-1048', customer: 'Nguyễn Minh Anh', payment: 'VNPay', total: '775.000₫', status: 'Đã thanh toán', className: 'paid' }, { id: 'RXN-1047', customer: 'Trần Gia Hân', payment: 'COD', total: '522.000₫', status: 'Đang đóng gói', className: 'packing' }, { id: 'RXN-1046', customer: 'Lê Quốc Việt', payment: 'Chuyển khoản', total: '1.128.000₫', status: 'Chờ xác nhận', className: 'pending' }];
  readonly providers = [{ logo: 'GHN', name: 'Giao Hàng Nhanh', description: 'Báo phí, tạo vận đơn và webhook trạng thái.', connected: true }, { logo: 'GHTK', name: 'Giao Hàng Tiết Kiệm', description: 'Giao toàn quốc và đối soát COD.', connected: true }, { logo: 'VT', name: 'Viettel Post', description: 'Giao tiêu chuẩn và chuyển phát nhanh.', connected: false }];
  readonly payments = [{ logo: 'COD', name: 'Thanh toán khi nhận hàng', description: 'Xác nhận đơn trước khi đóng gói.', connected: true }, { logo: 'BANK', name: 'Chuyển khoản ngân hàng', description: 'Đối soát theo mã đơn hàng.', connected: true }, { logo: 'VNP', name: 'VNPay', description: 'Cần Merchant ID, secret key và webhook.', connected: false }];
  currentSection(): AdminSection { return this.sections.find(section => section.id === this.activeSection()) ?? this.sections[0]; }
  selectSection(id: string): void { this.activeSection.set(id); this.search = ''; window.scrollTo({ top: 0, behavior: 'smooth' }); }
  filteredProducts() { const query = this.search.toLowerCase(); return this.store.products.filter(product => !query || `${product.name} ${product.slug}`.toLowerCase().includes(query)); }
  filteredStories() { const query = this.search.toLowerCase(); return this.store.stories.filter(story => !query || `${story.title} ${story.category}`.toLowerCase().includes(query)); }
  allOrders() { return [...this.store.orders().map(order => ({ id: order.id, customer: this.store.user()?.name ?? 'Khách hàng', payment: order.paymentMethod, total: this.store.formatPrice(order.total), status: order.status === 'CONFIRMED' ? 'Đã xác nhận' : 'Chờ thanh toán', className: order.status === 'CONFIRMED' ? 'paid' : 'pending' })), ...this.recentOrders]; }
  primaryAction(): void { this.store.notify(`${this.currentSection().action}: giao diện đã sẵn sàng, cần API để lưu dữ liệu thật`); }
  inspect(type: string, name: string): void { this.store.notify(`Đang mở ${type}: ${name} (chế độ demo)`); }
  configure(name: string): void { this.store.notify(`${name}: cần thông tin kết nối/API key để cấu hình thật`); }
  publishDraft(): void { this.store.notify('Bài viết đã được admin xuất bản ở chế độ demo'); }
  toggleSetting(name: string, setting: ReturnType<typeof signal<boolean>>): void { setting.update(value => !value); this.store.notify(`${name}: đã ${setting() ? 'bật' : 'tắt'} ở chế độ demo`); }
  summaryCount(): number { return this.activeSection() === 'categories' ? 5 : this.activeSection() === 'batches' ? 8 : this.activeSection() === 'customers' ? 126 : 3; }
}
