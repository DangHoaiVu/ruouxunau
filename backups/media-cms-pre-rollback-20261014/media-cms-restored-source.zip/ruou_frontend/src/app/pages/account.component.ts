import { NgTemplateOutlet } from '@angular/common';
import { Component, inject, signal } from '@angular/core';
import { Router, RouterLink } from '@angular/router';
import { StoreService } from '../core/store.service';

@Component({
  selector: 'app-account', imports: [RouterLink, NgTemplateOutlet],
  template: `
    <section class="page-hero mini"><div class="container"><p class="eyebrow light">Tài khoản</p><h1>Xin chào, {{ store.user()?.name }}</h1></div></section>
    <section class="section container account-layout">
      <aside class="account-nav">
        @for (tab of tabs; track tab.id) { <button type="button" [class.active]="activeTab() === tab.id" (click)="activeTab.set(tab.id)">{{ tab.label }}</button> }
        @if (store.user()?.role === 'ADMIN') { <a class="admin-link" routerLink="/admin">Mở trang quản trị ↗</a> }
        <button type="button" class="logout" (click)="logout()">Đăng xuất</button>
      </aside>
      <div class="account-content">
        @if (activeTab() === 'overview') {
          <div class="welcome-card"><p class="eyebrow">Thành viên Xứ Nẫu</p><h2>{{ store.user()?.name }}</h2><p>{{ store.user()?.email }}</p></div>
          <div class="account-stats"><button type="button" (click)="activeTab.set('orders')"><strong>{{ processingOrders() }}</strong><span>Đơn đang xử lý</span></button><button type="button" (click)="activeTab.set('orders')"><strong>{{ completedOrders() }}</strong><span>Đơn đã hoàn thành</span></button><button type="button" (click)="activeTab.set('favorites')"><strong>0</strong><span>Sản phẩm yêu thích</span></button></div>
          <section class="recent-orders"><div class="section-heading"><div><h2>Đơn hàng gần đây</h2></div></div><ng-container *ngTemplateOutlet="ordersView"></ng-container></section>
        }
        @if (activeTab() === 'orders') { <section class="account-panel"><p class="eyebrow">Lịch sử mua hàng</p><h2>Đơn hàng của tôi</h2><ng-container *ngTemplateOutlet="ordersView"></ng-container></section> }
        @if (activeTab() === 'addresses') { <section class="account-panel"><p class="eyebrow">Sổ địa chỉ</p><h2>Địa chỉ nhận hàng</h2><div class="empty-state compact"><span>⌖</span><h3>Chưa có địa chỉ đã lưu</h3><p>Địa chỉ sẽ được đồng bộ từ backend sau khi hoàn thiện API.</p><button class="button button-secondary" type="button" (click)="store.notify('Mẫu thêm địa chỉ sẽ được mở khi nối API tài khoản')">Thêm địa chỉ</button></div></section> }
        @if (activeTab() === 'favorites') { <section class="account-panel"><p class="eyebrow">Bộ sưu tập riêng</p><h2>Sản phẩm yêu thích</h2><div class="empty-state compact"><span>♡</span><h3>Chưa có sản phẩm yêu thích</h3><p>Khám phá bộ sưu tập và lưu lại hương vị phù hợp.</p><a class="button button-secondary" routerLink="/san-pham">Khám phá sản phẩm</a></div></section> }
        @if (activeTab() === 'profile') { <section class="account-panel"><p class="eyebrow">Hồ sơ</p><h2>Thông tin cá nhân</h2><dl class="profile-list"><div><dt>Họ tên</dt><dd>{{ store.user()?.name }}</dd></div><div><dt>Email</dt><dd>{{ store.user()?.email }}</dd></div><div><dt>Vai trò</dt><dd>{{ store.user()?.role === 'ADMIN' ? 'Quản trị viên' : 'Khách hàng' }}</dd></div></dl><button type="button" class="button button-secondary" (click)="store.notify('Tính năng chỉnh sửa hồ sơ đang chờ API Spring Boot')">Chỉnh sửa thông tin</button></section> }
      </div>
    </section>

    <ng-template #ordersView>
      @if (store.orders().length) { <div class="account-order-list">@for (order of store.orders(); track order.id) { <article><div><strong>#{{ order.id }}</strong><small>{{ order.createdAt }} · {{ order.itemCount }} sản phẩm</small></div><div><span>{{ paymentLabel(order.paymentMethod) }}</span><small>{{ order.shippingProvider }}</small></div><b>{{ store.formatPrice(order.total) }}</b><em [class.pending]="order.status === 'PENDING_PAYMENT'">{{ order.status === 'CONFIRMED' ? 'Đã xác nhận' : 'Chờ thanh toán' }}</em></article> }</div> }
      @else { <div class="empty-state compact"><span>□</span><h3>Chưa có đơn hàng</h3><p>Đơn hàng của bạn sẽ xuất hiện tại đây.</p><a class="button button-secondary" routerLink="/san-pham">Bắt đầu mua sắm</a></div> }
    </ng-template>
  `,
})
export class AccountComponent {
  readonly store = inject(StoreService); private readonly router = inject(Router);
  readonly tabs = [{ id: 'overview', label: 'Tổng quan' }, { id: 'orders', label: 'Đơn hàng' }, { id: 'addresses', label: 'Địa chỉ' }, { id: 'favorites', label: 'Yêu thích' }, { id: 'profile', label: 'Thông tin cá nhân' }];
  readonly activeTab = signal('overview');
  processingOrders(): number { return this.store.orders().filter(order => order.status !== 'CONFIRMED').length; }
  completedOrders(): number { return this.store.orders().filter(order => order.status === 'CONFIRMED').length; }
  paymentLabel(method: string): string { return method === 'VNPAY' ? 'VNPay' : method === 'BANK_TRANSFER' ? 'Chuyển khoản' : 'COD'; }
  logout(): void { this.store.logout(); this.router.navigateByUrl('/'); }
}
