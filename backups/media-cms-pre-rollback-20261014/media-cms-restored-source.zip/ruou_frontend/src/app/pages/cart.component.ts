import { Component, inject } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { StoreService } from '../core/store.service';

@Component({
  selector: 'app-cart', imports: [FormsModule, RouterLink],
  template: `
    <section class="page-hero mini"><div class="container"><p class="eyebrow light">Đơn hàng của bạn</p><h1>Giỏ hàng</h1></div></section>
    <section class="section container cart-layout">
      <div class="cart-list"><div class="cart-title"><h2>Sản phẩm <span>({{ store.cartCount() }})</span></h2><a routerLink="/san-pham">Tiếp tục mua sắm →</a></div>
        @for (item of store.cart(); track item.product.id) { <article class="cart-item"><img [src]="item.product.image" [alt]="item.product.name" /><div class="cart-item-info"><p class="eyebrow">{{ item.product.category }}</p><h3><a [routerLink]="['/san-pham', item.product.slug]">{{ item.product.name }}</a></h3><small>{{ item.product.volume }}ml · {{ item.product.alcohol }}% vol</small><button (click)="store.removeFromCart(item.product.id)">Xóa</button></div><div class="quantity"><button (click)="store.updateQuantity(item.product.id, item.quantity - 1)">−</button><span>{{ item.quantity }}</span><button (click)="store.updateQuantity(item.product.id, item.quantity + 1)">+</button></div><strong class="line-price">{{ store.formatPrice(item.product.price * item.quantity) }}</strong></article> } @empty { <div class="empty-state"><span>◌</span><h2>Giỏ hàng đang trống</h2><p>Hãy chọn một hương vị từ bộ sưu tập của chúng tôi.</p><a class="button button-primary" routerLink="/san-pham">Khám phá sản phẩm</a></div> }
      </div>
      @if (store.cart().length) { <aside class="order-summary"><h2>Tóm tắt đơn hàng</h2><label>Mã ưu đãi<div class="coupon"><input [(ngModel)]="coupon" placeholder="Nhập mã" /><button (click)="applyCoupon()">Áp dụng</button></div></label>@if (store.discount() > 0) { <p class="coupon-success">Đã áp dụng RUOUBD10 <button (click)="removeCoupon()">Bỏ mã</button></p> }<dl><div><dt>Tạm tính</dt><dd>{{ store.formatPrice(store.subtotal()) }}</dd></div><div><dt>Giảm giá</dt><dd>− {{ store.formatPrice(store.discount()) }}</dd></div><div><dt>Phí vận chuyển</dt><dd>Tính ở bước sau</dd></div><div class="summary-total"><dt>Tổng dự kiến</dt><dd>{{ store.formatPrice(store.subtotal() - store.discount()) }}</dd></div></dl><a class="button button-primary full" routerLink="/thanh-toan">Tiến hành thanh toán</a><small>Giá và tồn kho sẽ được backend kiểm tra lại trước khi tạo đơn.</small></aside> }
    </section>
  `,
})
export class CartComponent {
  readonly store = inject(StoreService); coupon = this.store.couponCode();
  applyCoupon(): void { if (this.store.applyCoupon(this.coupon)) this.store.notify('Áp dụng mã ưu đãi thành công'); else this.store.notify('Mã ưu đãi không hợp lệ'); }
  removeCoupon(): void { this.store.clearCoupon(); this.coupon = ''; this.store.notify('Đã bỏ mã ưu đãi'); }
}
