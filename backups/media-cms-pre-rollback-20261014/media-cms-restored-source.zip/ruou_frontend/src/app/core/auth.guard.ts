import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { StoreService } from './store.service';

export const authGuard: CanActivateFn = (_, state) => {
  const store = inject(StoreService); const router = inject(Router);
  return store.isAuthenticated() || router.createUrlTree(['/dang-nhap'], { queryParams: { returnUrl: state.url } });
};

export const adminGuard: CanActivateFn = () => {
  const store = inject(StoreService); const router = inject(Router);
  return store.user()?.role === 'ADMIN' || router.createUrlTree(['/dang-nhap'], { queryParams: { returnUrl: '/admin' } });
};
