export interface Product {
  id: number; slug: string; name: string; category: string; material: string; volume: number; alcohol: number; price: number; comparePrice?: number; stock: number; badge?: string; featured?: boolean; image: string; gallery: string[]; shortDescription: string; description: string; producer: string; origin: string; tastingNotes: string[];
}
export interface Story { id: number; slug: string; title: string; excerpt: string; category: string; image: string; author: string; publishedAt: string; readTime: number; featured?: boolean; content: string[]; }
export interface CartItem { product: Product; quantity: number; }
export interface User { name: string; email: string; role: 'CUSTOMER' | 'ADMIN'; }
export interface Order {
  id: string;
  createdAt: string;
  itemCount: number;
  total: number;
  paymentMethod: 'COD' | 'BANK_TRANSFER' | 'VNPAY';
  shippingProvider: string;
  status: 'PENDING_PAYMENT' | 'CONFIRMED';
}
