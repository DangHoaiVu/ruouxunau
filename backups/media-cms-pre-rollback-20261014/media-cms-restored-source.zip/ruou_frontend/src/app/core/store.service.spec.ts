import { TestBed } from '@angular/core/testing';
import { StoreService } from './store.service';

describe('StoreService', () => {
  let store: StoreService;

  beforeEach(() => {
    localStorage.clear();
    TestBed.configureTestingModule({});
    store = TestBed.inject(StoreService);
    store.login('khach@example.com', 'Khách thử nghiệm');
  });

  afterEach(() => localStorage.clear());

  it('removes a cart line when its quantity reaches zero', () => {
    const product = store.products[0];
    store.addToCart(product);

    store.updateQuantity(product.id, 0);

    expect(store.cart()).toEqual([]);
    expect(localStorage.getItem('ruou-cart')).toBe('[]');
  });

  it('never increases quantity beyond available stock', () => {
    const product = store.products[0];
    store.addToCart(product);

    store.updateQuantity(product.id, product.stock + 20);

    expect(store.cart()[0].quantity).toBe(product.stock);
  });

  it('persists a coupon through cart totals and clears it after order creation', () => {
    store.addToCart(store.products[0], 2);
    expect(store.applyCoupon(' ruoubd10 ')).toBe(true);
    expect(store.discount()).toBe(Math.min(store.subtotal() * .1, 100000));

    store.createOrder({ id: 'RXN-TEST', createdAt: '13/10/2026', itemCount: 2, total: store.subtotal() - store.discount(), paymentMethod: 'VNPAY', shippingProvider: 'GHN', status: 'PENDING_PAYMENT' });

    expect(store.cart()).toEqual([]);
    expect(store.couponCode()).toBe('');
    expect(store.orders()[0].status).toBe('PENDING_PAYMENT');
  });
});
