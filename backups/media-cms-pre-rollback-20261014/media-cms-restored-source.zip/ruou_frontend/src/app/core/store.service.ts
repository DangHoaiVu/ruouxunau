import { DOCUMENT } from '@angular/common';
import { computed, inject, Injectable, signal } from '@angular/core';
import { CartItem, Order, Product, User } from './models';
import { PRODUCTS, STORIES } from './mock-data';

@Injectable({ providedIn: 'root' })
export class StoreService {
  private readonly document = inject(DOCUMENT);
  readonly products = PRODUCTS;
  readonly stories = STORIES;
  readonly user = signal<User | null>(this.read<User>('ruou-user'));
  readonly cart = signal<CartItem[]>(this.read<CartItem[]>('ruou-cart') ?? []);
  readonly orders = signal<Order[]>(this.read<Order[]>('ruou-orders') ?? []);
  readonly couponCode = signal(localStorage.getItem('ruou-coupon') ?? '');
  readonly theme = signal<'light' | 'dark'>((localStorage.getItem('ruou-theme') as 'light' | 'dark') ?? 'light');
  readonly ageVerified = signal(localStorage.getItem('ruou-age') === 'yes');
  readonly toast = signal('');
  readonly isAuthenticated = computed(() => !!this.user());
  readonly cartCount = computed(() => this.cart().reduce((sum, item) => sum + item.quantity, 0));
  readonly subtotal = computed(() => this.cart().reduce((sum, item) => sum + item.product.price * item.quantity, 0));
  readonly discount = computed(() => this.couponCode() === 'RUOUBD10' ? Math.min(this.subtotal() * .1, 100000) : 0);
  readonly featuredProducts = computed(() => this.products.filter(product => product.featured));

  constructor() { this.reconcileCart(); this.applyTheme(); }
  confirmAge(): void { localStorage.setItem('ruou-age', 'yes'); this.ageVerified.set(true); }
  toggleTheme(): void { this.theme.update(value => value === 'light' ? 'dark' : 'light'); localStorage.setItem('ruou-theme', this.theme()); this.applyTheme(); }
  login(email: string, displayName?: string): void { const isAdmin = email.toLowerCase().includes('admin'); const user: User = { name: isAdmin ? 'Quản trị viên' : displayName?.trim() || 'Khách hàng Xứ Nẫu', email, role: isAdmin ? 'ADMIN' : 'CUSTOMER' }; this.user.set(user); this.persist('ruou-user', user); this.notify(`Xin chào, ${user.name}`); }
  logout(): void { this.user.set(null); localStorage.removeItem('ruou-user'); this.notify('Bạn đã đăng xuất'); }
  addToCart(product: Product, quantity = 1): boolean { if (!this.isAuthenticated()) return false; if (product.stock <= 0) { this.notify('Sản phẩm hiện đã hết hàng'); return true; } const items = this.cart().map(item => ({ ...item })); const existing = items.find(item => item.product.id === product.id); if (existing && existing.quantity >= product.stock) { this.notify(`Chỉ còn ${product.stock} sản phẩm trong kho`); return true; } if (existing) existing.quantity = Math.min(existing.quantity + quantity, product.stock); else items.push({ product, quantity: Math.max(1, Math.min(quantity, product.stock)) }); this.cart.set(items); this.persist('ruou-cart', items); this.notify(`Đã thêm ${product.name} vào giỏ`); return true; }
  updateQuantity(productId: number, quantity: number): void { if (quantity <= 0) { this.removeFromCart(productId); return; } const item = this.cart().find(entry => entry.product.id === productId); if (!item) return; const safeQuantity = Math.min(quantity, item.product.stock); if (quantity > item.product.stock) this.notify(`Chỉ còn ${item.product.stock} sản phẩm trong kho`); const items = this.cart().map(entry => entry.product.id === productId ? { ...entry, quantity: safeQuantity } : entry); this.cart.set(items); this.persist('ruou-cart', items); }
  removeFromCart(productId: number): void { const items = this.cart().filter(item => item.product.id !== productId); this.cart.set(items); this.persist('ruou-cart', items); if (!items.length) this.clearCoupon(); this.notify('Đã xóa sản phẩm khỏi giỏ'); }
  applyCoupon(code: string): boolean { const normalized = code.trim().toUpperCase(); if (normalized !== 'RUOUBD10') { this.clearCoupon(); return false; } this.couponCode.set(normalized); localStorage.setItem('ruou-coupon', normalized); return true; }
  clearCoupon(): void { this.couponCode.set(''); localStorage.removeItem('ruou-coupon'); }
  createOrder(order: Order): void { const orders = [order, ...this.orders()]; this.orders.set(orders); this.persist('ruou-orders', orders); this.cart.set([]); localStorage.removeItem('ruou-cart'); this.clearCoupon(); }
  notify(message: string): void { this.toast.set(message); window.setTimeout(() => { if (this.toast() === message) this.toast.set(''); }, 2800); }
  formatPrice(price: number): string { return new Intl.NumberFormat('vi-VN', { style: 'currency', currency: 'VND' }).format(price); }
  private reconcileCart(): void {
    const reconciled = this.cart().flatMap(item => {
      const product = this.products.find(entry => entry.id === item.product.id);
      if (!product || product.stock <= 0) return [];
      return [{ product, quantity: Math.max(1, Math.min(item.quantity, product.stock)) }];
    });
    if (JSON.stringify(reconciled) !== JSON.stringify(this.cart())) { this.cart.set(reconciled); this.persist('ruou-cart', reconciled); }
    if (!reconciled.length) this.clearCoupon();
  }
  private applyTheme(): void { this.document.documentElement.dataset['theme'] = this.theme(); }
  private read<T>(key: string): T | null { try { const value = localStorage.getItem(key); return value ? JSON.parse(value) as T : null; } catch { return null; } }
  private persist(key: string, value: unknown): void { localStorage.setItem(key, JSON.stringify(value)); }
}
