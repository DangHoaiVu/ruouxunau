package com.ruouxunau.catalog.api;

import com.ruouxunau.catalog.domain.MediaEntity;

import java.time.Instant;

public record MediaResponse(
        String id,
        String url,
        String mimeType,
        Integer width,
        Integer height,
        String altText,
        String checksum,
        Instant createdAt) {

    public static MediaResponse from(MediaEntity media) {
        return new MediaResponse(
                media.getId(), media.getUrl(), media.getMimeType(), media.getWidth(), media.getHeight(),
                media.getAltText(), media.getChecksum(), media.getCreatedAt());
    }
}
