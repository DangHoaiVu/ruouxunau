-- Run only when the application migration runner is intentionally disabled.
-- Canonical migration: src/main/resources/db/migration/V6__site_content.sql
SOURCE ../src/main/resources/db/migration/V6__site_content.sql;
