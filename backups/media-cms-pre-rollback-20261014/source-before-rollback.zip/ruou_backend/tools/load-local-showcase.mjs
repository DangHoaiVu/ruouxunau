const baseUrl = process.env.API_BASE_URL || 'http://127.0.0.1:8080/api/v1';
const email = process.env.ADMIN_EMAIL;
const password = process.env.ADMIN_PASSWORD;

if (!email || !password) {
  throw new Error('ADMIN_EMAIL và ADMIN_PASSWORD là bắt buộc. Script không lưu thông tin đăng nhập.');
}

async function request(path, options = {}) {
  const response = await fetch(`${baseUrl}${path}`, {
    ...options,
    headers: { 'content-type': 'application/json', ...(options.headers || {}), ...(token ? { authorization: `Bearer ${token}` } : {}) },
  });
  if (response.status === 204) return null;
  const text = await response.text();
  const body = text ? JSON.parse(text) : null;
  if (!response.ok) throw new Error(`${options.method || 'GET'} ${path} -> ${response.status}: ${body?.detail || body?.message || text}`);
  return body;
}

let token = '';
const session = await request('/auth/login', { method: 'POST', body: JSON.stringify({ email, password }) });
token = session.accessToken;

const imageSources = [
  ['bau-da-binh-su', 'https://www.chodulich.com.vn/images/2021/ruou-bau-da4.jpg', 'Bình rượu Bàu Đá truyền thống'],
  ['bo-suu-tap-bau-da', 'https://chonongsanonline.com/public/uploads/all/zbk2tUCek6Bl34hIDJXXVxrF9q3zjJGMGDaqXLYR.jpg', 'Bộ sưu tập bình rượu Bàu Đá'],
  ['bau-da-rong-xanh', 'https://www.chodulich.cakhotranluan.com/images/2021/ruou-bau-da1.jpg', 'Bình sứ họa tiết rồng xanh'],
  ['bau-da-bau-trang', 'https://www.chodulich.cakhotranluan.com/images/2021/ruou-bau-da.jpg', 'Bình rượu Bàu Đá dáng bầu'],
  ['lang-nghe-cu-lam', 'https://peacetour.com.vn/Upload/Article/4bbf1697-0b66-4fff-ae45-e4309605b1d6/du-lich-quy-nhon-nau-ruou.jpeg', 'Người thợ chưng cất rượu tại làng nghề'],
  ['be-chung-cat', 'https://cdn2.tuoitre.vn/thumb_w/1200/tto/i/s626/2009/06/21/r57uMZJy.jpg', 'Bếp chưng cất rượu Bàu Đá'],
  ['chum-u-ruou', 'https://cdn.baogialai.com.vn/images/60e08242b719152671f3736e312ec58c973e88f5d4851a5ab55ad760db8900fd4a05425ab90370a65d8ab075e0bcc262/241828.jpg', 'Chum ủ rượu truyền thống'],
  ['giu-lua-lang-nghe', 'https://media.vietnamplus.vn/images/7255a701687d11cb8c6bbc58a6c807854bcf0cd6242227383ff15377d77f3aabc72ac7da06810d9ace14e4cdbb15319ca74f6b1bfe70b3203772c7979020cefa/ruou_bau_da.jpg', 'Người thợ giữ lửa lò rượu'],
  ['vao-vu-tet', 'https://thanhnien.mediacdn.vn/uploaded/trongnth/2021_02_07/langnghe4_AKFB.jpg?width=500', 'Làng nghề nấu rượu vào vụ Tết'],
  ['men-la', 'https://images.baodantoc.vn/uploads/2021/Th%C3%A1ng_12/Ng%C3%A0y%201/TRUNG/R%C6%B0%E1%BB%A3u%20mem%20l%C3%A1/6%20-%20OK.jpg', 'Chưng cất rượu men lá truyền thống'],
];

const existingMediaPage = await request('/admin/media?page=0&size=100');
const mediaByUrl = new Map(existingMediaPage.items.map(item => [item.url, item]));
const media = {};
for (const [key, url, altText] of imageSources) {
  let item = mediaByUrl.get(url);
  if (!item) item = await request('/admin/media', { method: 'POST', body: JSON.stringify({ url, mimeType: 'image/jpeg', width: null, height: null, altText, checksum: null }) });
  media[key] = item;
}

const categoryInputs = [
  { name: 'Rượu gạo', slug: 'ruou-gao', description: 'Rượu chưng cất từ gạo tuyển chọn.', status: 'ACTIVE', sortOrder: 1 },
  { name: 'Rượu nếp', slug: 'ruou-nep', description: 'Hương nếp tròn đầy, hậu vị êm.', status: 'ACTIVE', sortOrder: 2 },
  { name: 'Rượu đậu xanh', slug: 'ruou-dau-xanh', description: 'Dòng rượu Bàu Đá phối nguyên liệu đậu xanh.', status: 'ACTIVE', sortOrder: 3 },
  { name: 'Quà tặng', slug: 'qua-tang', description: 'Bình và hộp quà mang dấu ấn Bình Định.', status: 'ACTIVE', sortOrder: 4 },
];
const existingCategories = await request('/admin/categories');
const categories = {};
for (const input of categoryInputs) {
  categories[input.slug] = existingCategories.find(item => item.slug === input.slug) || await request('/admin/categories', { method: 'POST', body: JSON.stringify(input) });
}

const existingProducers = await request('/admin/producers');
let producer = existingProducers.find(item => item.name === 'Làng nghề Bàu Đá Xứ Nẫu');
if (!producer) producer = await request('/admin/producers', { method: 'POST', body: JSON.stringify({ name: 'Làng nghề Bàu Đá Xứ Nẫu', legalName: null, origin: 'Nhơn Lộc, An Nhơn, Bình Định', contact: null, status: 'ACTIVE' }) });

const productInputs = [
  ['Bàu Đá Gạo Truyền Thống', 'bau-da-gao-truyen-thong', 'ruou-gao', 'bau-da-binh-su', 500, 45, 260000, 'RXN-BDG-500', 'Trong trẻo, nồng ấm và có hậu vị gạo thanh.'],
  ['Bàu Đá Nếp Hương', 'bau-da-nep-huong', 'ruou-nep', 'bo-suu-tap-bau-da', 500, 48, 295000, 'RXN-BDN-500', 'Hương nếp chín dịu, vị rượu dày và êm.'],
  ['Bàu Đá Đậu Xanh', 'bau-da-dau-xanh', 'ruou-dau-xanh', 'bau-da-rong-xanh', 500, 45, 320000, 'RXN-BDX-500', 'Thoảng hương đậu xanh, hậu vị bùi và gọn.'],
  ['Bàu Đá Bình Sứ Rồng', 'bau-da-binh-su-rong', 'qua-tang', 'bau-da-bau-trang', 500, 45, 390000, 'RXN-BSR-500', 'Rượu gạo truyền thống trong bình sứ họa tiết Việt.'],
  ['Nếp Lứt Xứ Nẫu', 'nep-lut-xu-nau', 'ruou-nep', 'chum-u-ruou', 500, 35, 275000, 'RXN-NLX-500', 'Dịu hơn dòng truyền thống, hương ngũ cốc rõ nét.'],
  ['Men Lá An Lão', 'men-la-an-lao', 'ruou-gao', 'men-la', 500, 38, 310000, 'RXN-MLA-500', 'Hương men lá mộc mạc, cân bằng và dễ thưởng thức.'],
  ['Bàu Đá Tuyển Chọn', 'bau-da-tuyen-chon', 'ruou-gao', 'lang-nghe-cu-lam', 750, 50, 480000, 'RXN-BTC-750', 'Mẻ rượu tuyển chọn, đậm vị và kéo dài hậu ấm.'],
  ['Song Bình Đất Võ', 'song-binh-dat-vo', 'qua-tang', 'giu-lua-lang-nghe', 1000, 45, 850000, 'RXN-SBD-1000', 'Bộ quà hai bình dành cho dịp sum họp và tri ân.'],
];
const existingProducts = (await request('/admin/products?page=0&size=100')).items;
for (const [name, slug, categorySlug, mediaKey, volumeMl, alcoholPercent, price, sku, shortDescription] of productInputs) {
  if (existingProducts.some(item => item.slug === slug)) continue;
  const product = await request('/admin/products', { method: 'POST', body: JSON.stringify({
    categoryId: categories[categorySlug].id, producerId: producer.id, name, slug, shortDescription,
    description: `${name} được xây dựng như một sản phẩm tiêu biểu của bộ sưu tập Xứ Nẫu, tôn trọng nguyên liệu địa phương, nhịp chưng cất chậm và tinh thần thưởng thức có trách nhiệm.`,
    storageInstructions: 'Đậy kín, đặt nơi khô ráo, tránh ánh nắng trực tiếp và nguồn nhiệt.', origin: 'Bình Định, Việt Nam', status: 'ACTIVE', seoTitle: `${name} | Rượu Xứ Nẫu`, seoDescription: shortDescription,
  }) });
  await request('/admin/variants', { method: 'POST', body: JSON.stringify({ productId: product.id, sku, barcode: null, volumeMl, alcoholPercent, price, comparePrice: null, weightGram: volumeMl + 450, status: 'ACTIVE' }) });
  await request(`/admin/products/${product.id}/images`, { method: 'POST', body: JSON.stringify({ mediaId: media[mediaKey].id, sortOrder: 0, primary: true }) });
}

const articleCategoryInputs = [
  { name: 'Làng nghề', slug: 'lang-nghe', description: 'Con người và không gian làm nghề.', status: 'ACTIVE', sortOrder: 1 },
  { name: 'Kỹ nghệ', slug: 'ky-nghe', description: 'Quy trình, nguyên liệu và kinh nghiệm thủ công.', status: 'ACTIVE', sortOrder: 2 },
  { name: 'Thưởng thức', slug: 'thuong-thuc', description: 'Cách cảm nhận và sử dụng có trách nhiệm.', status: 'ACTIVE', sortOrder: 3 },
  { name: 'Văn hóa', slug: 'van-hoa', description: 'Rượu trong đời sống văn hóa miền đất võ.', status: 'ACTIVE', sortOrder: 4 },
];
const existingArticleCategories = await request('/admin/article-categories');
const articleCategories = {};
for (const input of articleCategoryInputs) articleCategories[input.slug] = existingArticleCategories.find(item => item.slug === input.slug) || await request('/admin/article-categories', { method: 'POST', body: JSON.stringify(input) });

const articleInputs = [
  ['Ngọn lửa không tắt ở làng Bàu Đá', 'ngon-lua-khong-tat-o-lang-bau-da', 'lang-nghe', 'giu-lua-lang-nghe', 'Theo chân người thợ gìn giữ nhịp lửa đều qua từng mẻ rượu.', 'Lửa trong lò không cần bùng lớn, nhưng phải đều và bền. Người thợ nhìn màu lửa, nghe tiếng sôi và điều chỉnh từng thanh củi để dòng rượu ra chậm, trong.\n\nỞ làng nghề, kinh nghiệm ấy được truyền bằng những buổi đứng bếp cùng nhau. Mỗi thế hệ thêm một cách làm sạch hơn, an toàn hơn nhưng vẫn giữ sự kiên nhẫn làm nên hương vị riêng.'],
  ['Từ hạt gạo đến giọt rượu trong', 'tu-hat-gao-den-giot-ruou-trong', 'ky-nghe', 'be-chung-cat', 'Bốn chặng chính tạo nên một mẻ rượu gạo thủ công.', 'Gạo được chọn theo độ thơm, độ dẻo và sự đồng đều. Sau khi nấu chín, cơm được làm nguội đúng mức trước khi trộn men.\n\nQuá trình ủ tạo hương, còn chưng cất quyết định độ trong và sự cân bằng. Dòng đầu và dòng cuối được kiểm soát kỹ để phần rượu giữ lại có chất lượng ổn định.'],
  ['Nước nguồn và hương vị Bàu Đá', 'nuoc-nguon-va-huong-vi-bau-da', 'ky-nghe', 'lang-nghe-cu-lam', 'Vì sao nguồn nước luôn được nhắc đến khi kể về rượu Bàu Đá.', 'Nước tham gia vào nhiều công đoạn, từ nấu cơm đến làm nguội hệ thống chưng cất. Độ khoáng và sự sạch của nước ảnh hưởng trực tiếp đến cảm nhận cuối cùng.\n\nNgày nay, người làm nghề kết hợp kinh nghiệm địa phương với kiểm soát chất lượng để bảo đảm mỗi mẻ rượu an toàn và nhất quán hơn.'],
  ['Nhịp ủ men qua những ngày mưa', 'nhip-u-men-qua-nhung-ngay-mua', 'ky-nghe', 'chum-u-ruou', 'Nhiệt độ và độ ẩm thay đổi buộc người thợ lắng nghe mẻ ủ kỹ hơn.', 'Men là phần sống động nhất của quy trình. Khi trời ẩm, thời gian và cách giữ nhiệt cần được điều chỉnh để cơm rượu chuyển hóa từ từ.\n\nKhông có một con số cứng cho mọi ngày. Sự ổn định đến từ việc ghi chép, quan sát và kiểm tra thay vì chỉ dựa vào thói quen.'],
  ['Một chén rượu trong mâm cơm Xứ Nẫu', 'mot-chen-ruou-trong-mam-com-xu-nau', 'van-hoa', 'vao-vu-tet', 'Rượu hiện diện như lời mời, sự sẻ chia và một giới hạn cần được tôn trọng.', 'Trong những dịp gặp gỡ, chén rượu nhỏ mở đầu câu chuyện và thể hiện sự hiếu khách. Giá trị nằm ở khoảnh khắc quây quần, không nằm ở việc uống nhiều.\n\nThưởng thức có trách nhiệm là biết dừng đúng lúc, không mời người dưới 18 tuổi và tuyệt đối không lái xe sau khi uống.'],
  ['Chọn bình rượu làm quà miền đất võ', 'chon-binh-ruou-lam-qua-mien-dat-vo', 'thuong-thuc', 'bo-suu-tap-bau-da', 'Gợi ý chọn dung tích, dáng bình và câu chuyện phù hợp người nhận.', 'Một món quà đẹp bắt đầu từ sự phù hợp. Bình 500 ml gọn cho cuộc gặp thân tình, trong khi bộ song bình phù hợp dịp tri ân hoặc sum họp.\n\nNên giữ nhãn, thông tin nồng độ và nguồn gốc rõ ràng. Bao bì chắc chắn giúp món quà đến tay người nhận trọn vẹn.'],
  ['Cách cảm nhận rượu gạo bằng ba bước', 'cach-cam-nhan-ruou-gao-bang-ba-buoc', 'thuong-thuc', 'bau-da-binh-su', 'Nhìn độ trong, cảm hương và nhấp một lượng nhỏ để hiểu tính cách mỗi dòng.', 'Trước hết, quan sát độ trong dưới ánh sáng dịu. Tiếp theo, đưa chén lại gần để cảm nhận hương mà không cần hít quá sâu.\n\nCuối cùng, nhấp một lượng nhỏ và để ý sự chuyển đổi từ vị đầu đến hậu vị. Uống chậm, dùng cùng món ăn và luôn chuẩn bị phương án di chuyển an toàn.'],
  ['Người trẻ kể lại chuyện làng nghề', 'nguoi-tre-ke-lai-chuyen-lang-nghe', 'lang-nghe', 'bau-da-rong-xanh', 'Thiết kế, nội dung số và truy xuất nguồn gốc đang tạo một cách tiếp cận mới.', 'Giữ nghề không có nghĩa là giữ nguyên mọi thứ. Người trẻ đưa hình ảnh, câu chuyện và thông tin sản phẩm lên môi trường số để khách hàng hiểu điều mình đang chọn.\n\nSự đổi mới có giá trị khi đi cùng minh bạch về nguyên liệu, nồng độ, nơi sản xuất và trách nhiệm với người dùng cuối.'],
];
const existingArticles = (await request('/admin/articles?page=0&size=100')).items;
for (const [title, slug, categorySlug, mediaKey, excerpt, content] of articleInputs) {
  if (existingArticles.some(item => item.slug === slug)) continue;
  const article = await request('/admin/articles', { method: 'POST', body: JSON.stringify({ categoryId: articleCategories[categorySlug].id, featuredMediaId: media[mediaKey].id, title, slug, excerpt, content, seoTitle: `${title} | Tạp chí Xứ Nẫu`, seoDescription: excerpt }) });
  await request(`/admin/articles/${article.id}/submit-review`, { method: 'POST', body: '{}' });
  await request(`/admin/articles/${article.id}/publish`, { method: 'POST', body: '{}' });
}

const existingSlides = await request('/admin/site-content/hero-slides');
const slideInputs = [
  ['Giọt nồng kể chuyện quê', 'Từ miền đất võ Bình Định', 'Một hành trình từ hạt gạo, nguồn nước và bàn tay người thợ.', 'lang-nghe-cu-lam', 1, '/san-pham', 'Khám phá bộ sưu tập'],
  ['Giữ lửa một làng nghề', 'Kỹ nghệ qua nhiều thế hệ', 'Mỗi mẻ rượu là sự kiên nhẫn với nhiệt độ, thời gian và nguyên liệu.', 'giu-lua-lang-nghe', 2, '/cau-chuyen', 'Đọc chuyện làng nghề'],
  ['Hương vị cho ngày sum họp', 'Quà từ Xứ Nẫu', 'Chọn một bình rượu mang theo câu chuyện và dấu ấn miền đất võ.', 'bau-da-binh-su', 3, '/san-pham?category=qua-tang', 'Xem quà tặng'],
  ['Trong từng giọt là thời gian', 'Chưng cất thủ công', 'Dòng rượu đi chậm để giữ lại sự trong trẻo và hậu vị ấm.', 'be-chung-cat', 4, '/cau-chuyen/tu-hat-gao-den-giot-ruou-trong', 'Xem quy trình'],
];
for (const [title, eyebrow, description, mediaKey, sortOrder, ctaPath, ctaLabel] of slideInputs) {
  if (existingSlides.some(item => item.title === title)) continue;
  await request('/admin/site-content/hero-slides', { method: 'POST', body: JSON.stringify({ desktopMediaId: media[mediaKey].id, mobileMediaId: null, altText: media[mediaKey].altText, eyebrow, title, description, ctaLabel, ctaPath, sortOrder, visibleFrom: null, visibleUntil: null, status: 'ACTIVE', version: null }) });
}

const existingSteps = await request('/admin/site-content/process-steps');
const stepInputs = [
  ['Chọn gạo', 'Hạt gạo đều, thơm và có nguồn gốc rõ ràng.', 'Nguyên liệu được sàng lọc, làm sạch và định lượng cho từng mẻ để tạo nền hương ổn định.', 'Chuẩn bị trong ngày', 'bau-da-binh-su', 1],
  ['Ủ men', 'Cơm rượu được giữ ở nhiệt độ và độ ẩm phù hợp.', 'Men được trộn khi cơm đã nguội đúng mức. Người thợ theo dõi mùi, độ ẩm và thời gian chuyển hóa.', 'Khoảng 3–5 ngày', 'chum-u-ruou', 2],
  ['Chưng cất', 'Lửa đều để dòng rượu ra chậm và trong.', 'Hơi rượu đi qua hệ thống làm lạnh rồi ngưng tụ. Từng phần dòng rượu được kiểm soát để giữ chất lượng.', 'Nhiều giờ liên tục', 'be-chung-cat', 3],
  ['Nghỉ rượu', 'Hương vị ổn định trước khi đóng bình.', 'Rượu sau chưng cất được để nghỉ trong điều kiện phù hợp, kiểm tra cảm quan và thông tin nồng độ trước khi hoàn thiện.', 'Tùy từng dòng rượu', 'giu-lua-lang-nghe', 4],
];
for (const [title, shortDescription, longDescription, duration, mediaKey, sortOrder] of stepInputs) {
  if (existingSteps.some(item => item.title === title)) continue;
  await request('/admin/site-content/process-steps', { method: 'POST', body: JSON.stringify({ mediaId: media[mediaKey].id, title, shortDescription, longDescription, duration, altText: media[mediaKey].altText, sortOrder, status: 'ACTIVE', version: null }) });
}

const summary = {
  products: (await request('/products?page=0&size=100')).totalElements,
  articles: (await request('/articles?page=0&size=100')).totalElements,
  slides: (await request('/hero-slides')).length,
  processSteps: (await request('/process-steps')).length,
};
console.log(JSON.stringify(summary));
