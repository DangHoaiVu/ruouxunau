package com.ruouxunau.sitecontent.api;

import com.ruouxunau.sitecontent.service.SiteContentService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.net.URI;
import java.util.List;

@RestController
@RequestMapping("/api/v1/admin/site-content")
@PreAuthorize("hasAuthority('SITE_CONTENT_MANAGE')")
public class AdminSiteContentController {
    private final SiteContentService service;
    public AdminSiteContentController(SiteContentService service) { this.service = service; }

    @GetMapping("/settings")
    ResponseEntity<SiteSettingsResponse> settings() { return ResponseEntity.ofNullable(service.adminSettings()); }

    @PutMapping("/settings")
    SiteSettingsResponse saveSettings(@AuthenticationPrincipal Jwt jwt, @Valid @RequestBody SiteSettingsRequest request) {
        return service.saveSettings(jwt.getSubject(), request);
    }

    @GetMapping("/hero-slides")
    List<HeroSlideResponse> slides() { return service.adminSlides(); }

    @PostMapping("/hero-slides")
    ResponseEntity<HeroSlideResponse> createSlide(@AuthenticationPrincipal Jwt jwt, @Valid @RequestBody HeroSlideRequest request) {
        HeroSlideResponse response = service.createSlide(jwt.getSubject(), request);
        return ResponseEntity.created(URI.create("/api/v1/admin/site-content/hero-slides/" + response.id())).body(response);
    }

    @PatchMapping("/hero-slides/{id}")
    HeroSlideResponse updateSlide(@AuthenticationPrincipal Jwt jwt, @PathVariable String id, @Valid @RequestBody HeroSlideRequest request) {
        return service.updateSlide(jwt.getSubject(), id, request);
    }

    @DeleteMapping("/hero-slides/{id}")
    ResponseEntity<Void> deleteSlide(@AuthenticationPrincipal Jwt jwt, @PathVariable String id) {
        service.deleteSlide(jwt.getSubject(), id); return ResponseEntity.noContent().build();
    }

    @GetMapping("/process-steps")
    List<ProcessStepResponse> processSteps() { return service.adminProcessSteps(); }

    @PostMapping("/process-steps")
    ResponseEntity<ProcessStepResponse> createProcessStep(@AuthenticationPrincipal Jwt jwt, @Valid @RequestBody ProcessStepRequest request) {
        ProcessStepResponse response = service.createProcessStep(jwt.getSubject(), request);
        return ResponseEntity.created(URI.create("/api/v1/admin/site-content/process-steps/" + response.id())).body(response);
    }

    @PatchMapping("/process-steps/{id}")
    ProcessStepResponse updateProcessStep(@AuthenticationPrincipal Jwt jwt, @PathVariable String id, @Valid @RequestBody ProcessStepRequest request) {
        return service.updateProcessStep(jwt.getSubject(), id, request);
    }

    @DeleteMapping("/process-steps/{id}")
    ResponseEntity<Void> deleteProcessStep(@AuthenticationPrincipal Jwt jwt, @PathVariable String id) {
        service.deleteProcessStep(jwt.getSubject(), id); return ResponseEntity.noContent().build();
    }
}
