package com.ruouxunau.sitecontent.api;

import com.ruouxunau.catalog.domain.PublicationStatus;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

public record ProcessStepRequest(
        @Size(max = 26) String mediaId,
        @NotBlank @Size(max = 160) String title,
        @NotBlank @Size(max = 300) String shortDescription,
        @NotBlank String longDescription,
        @Size(max = 120) String duration,
        @Size(max = 255) String altText,
        int sortOrder,
        @NotNull PublicationStatus status,
        Long version) {
}
