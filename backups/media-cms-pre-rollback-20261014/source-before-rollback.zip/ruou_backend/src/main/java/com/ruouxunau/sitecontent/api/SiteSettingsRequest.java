package com.ruouxunau.sitecontent.api;

import com.ruouxunau.catalog.domain.PublicationStatus;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

public record SiteSettingsRequest(
        @Size(max = 20) @Pattern(regexp = "^[0-9+().\\s-]*$", message = "Số điện thoại không hợp lệ") String phone,
        @Email @Size(max = 254) String email,
        @Size(max = 500) String address,
        @Size(max = 255) String businessHours,
        @Size(max = 2048) String facebookUrl,
        @Size(max = 2048) String tiktokUrl,
        @Size(max = 2048) String youtubeUrl,
        @Size(max = 2048) String zaloUrl,
        @Size(max = 2048) String directionsUrl,
        @Size(max = 2048) String embedUrl,
        @NotNull PublicationStatus status,
        Long version) {
}
