package com.ruouxunau.sitecontent.api;

import com.ruouxunau.catalog.domain.PublicationStatus;
import java.time.Instant;

public record HeroSlideResponse(
        String id,
        String desktopMediaId,
        String desktopImageUrl,
        String mobileMediaId,
        String mobileImageUrl,
        String altText,
        String eyebrow,
        String title,
        String description,
        String ctaLabel,
        String ctaPath,
        int sortOrder,
        Instant visibleFrom,
        Instant visibleUntil,
        PublicationStatus status,
        long version,
        Instant createdAt,
        Instant updatedAt) {
}
