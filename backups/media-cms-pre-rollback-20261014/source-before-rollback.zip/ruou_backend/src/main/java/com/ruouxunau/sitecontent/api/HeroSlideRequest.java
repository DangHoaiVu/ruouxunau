package com.ruouxunau.sitecontent.api;

import com.ruouxunau.catalog.domain.PublicationStatus;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import java.time.Instant;

public record HeroSlideRequest(
        @NotBlank @Size(max = 26) String desktopMediaId,
        @Size(max = 26) String mobileMediaId,
        @NotBlank @Size(max = 255) String altText,
        @Size(max = 120) String eyebrow,
        @NotBlank @Size(max = 220) String title,
        @Size(max = 600) String description,
        @Size(max = 80) String ctaLabel,
        @Size(max = 255) String ctaPath,
        int sortOrder,
        Instant visibleFrom,
        Instant visibleUntil,
        @NotNull PublicationStatus status,
        Long version) {
}
