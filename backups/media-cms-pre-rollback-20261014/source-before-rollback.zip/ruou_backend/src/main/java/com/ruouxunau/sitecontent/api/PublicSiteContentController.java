package com.ruouxunau.sitecontent.api;

import com.ruouxunau.sitecontent.service.SiteContentService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/v1")
public class PublicSiteContentController {
    private final SiteContentService service;
    public PublicSiteContentController(SiteContentService service) { this.service = service; }

    @GetMapping("/site-settings")
    ResponseEntity<SiteSettingsResponse> settings() { return ResponseEntity.ofNullable(service.publicSettings()); }

    @GetMapping("/hero-slides")
    List<HeroSlideResponse> slides() { return service.publicSlides(); }

    @GetMapping("/process-steps")
    List<ProcessStepResponse> processSteps() { return service.publicProcessSteps(); }
}
