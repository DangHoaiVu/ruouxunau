package com.ruouxunau.sitecontent.service;

import com.ruouxunau.catalog.domain.PublicationStatus;
import com.ruouxunau.shared.audit.AuditService;
import com.ruouxunau.shared.exception.BadRequestException;
import com.ruouxunau.shared.exception.ConflictException;
import com.ruouxunau.shared.exception.ResourceNotFoundException;
import com.ruouxunau.shared.persistence.IdGenerator;
import com.ruouxunau.sitecontent.api.HeroSlideRequest;
import com.ruouxunau.sitecontent.api.HeroSlideResponse;
import com.ruouxunau.sitecontent.api.ProcessStepRequest;
import com.ruouxunau.sitecontent.api.ProcessStepResponse;
import com.ruouxunau.sitecontent.api.SiteSettingsRequest;
import com.ruouxunau.sitecontent.api.SiteSettingsResponse;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.net.URI;
import java.net.URISyntaxException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.Clock;
import java.time.Instant;
import java.util.List;
import java.util.Locale;
import java.util.Set;

@Service
public class SiteContentService {

    private static final Set<String> GOOGLE_MAP_HOSTS = Set.of("google.com", "www.google.com", "maps.google.com");
    private static final Set<String> DIRECTIONS_HOSTS = Set.of("google.com", "www.google.com", "maps.google.com", "maps.app.goo.gl");
    private final JdbcTemplate jdbc;
    private final AuditService audit;
    private final Clock clock;

    public SiteContentService(JdbcTemplate jdbc, AuditService audit, Clock clock) {
        this.jdbc = jdbc;
        this.audit = audit;
        this.clock = clock;
    }

    @Transactional(readOnly = true)
    public SiteSettingsResponse publicSettings() {
        return settings("where status = 'ACTIVE' order by updated_at desc limit 1");
    }

    @Transactional(readOnly = true)
    public SiteSettingsResponse adminSettings() {
        return settings("order by updated_at desc limit 1");
    }

    @Transactional
    public SiteSettingsResponse saveSettings(String actorId, SiteSettingsRequest request) {
        validateSettings(request);
        SiteSettingsResponse before = adminSettings();
        Instant now = clock.instant();
        if (before == null) {
            String id = IdGenerator.newUlid(clock);
            jdbc.update("""
                    insert into site_settings
                    (id, phone, email, address, business_hours, facebook_url, tiktok_url, youtube_url, zalo_url,
                     directions_url, embed_url, status, version, created_at, updated_at)
                    values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0, ?, ?)
                    """, id, trim(request.phone()), trim(request.email()), trim(request.address()), trim(request.businessHours()),
                    trim(request.facebookUrl()), trim(request.tiktokUrl()), trim(request.youtubeUrl()), trim(request.zaloUrl()),
                    trim(request.directionsUrl()), trim(request.embedUrl()), request.status().name(), now, now);
            SiteSettingsResponse after = adminSettings();
            audit.record(actorId, "SITE_SETTINGS_CREATED", "SITE_SETTINGS", id, null, after);
            return after;
        }
        requireVersion(request.version(), before.version(), "SITE_SETTINGS_VERSION_CONFLICT");
        int changed = jdbc.update("""
                update site_settings set phone=?, email=?, address=?, business_hours=?, facebook_url=?, tiktok_url=?,
                youtube_url=?, zalo_url=?, directions_url=?, embed_url=?, status=?, version=version+1, updated_at=?
                where id=? and version=?
                """, trim(request.phone()), trim(request.email()), trim(request.address()), trim(request.businessHours()),
                trim(request.facebookUrl()), trim(request.tiktokUrl()), trim(request.youtubeUrl()), trim(request.zaloUrl()),
                trim(request.directionsUrl()), trim(request.embedUrl()), request.status().name(), now, before.id(), request.version());
        ensureChanged(changed, "SITE_SETTINGS_VERSION_CONFLICT");
        SiteSettingsResponse after = adminSettings();
        audit.record(actorId, "SITE_SETTINGS_UPDATED", "SITE_SETTINGS", before.id(), before, after);
        return after;
    }

    @Transactional(readOnly = true)
    public List<HeroSlideResponse> publicSlides() {
        Instant now = clock.instant();
        return jdbc.query(heroSelect() + """
                where h.status='ACTIVE' and h.deleted_at is null
                  and (h.visible_from is null or h.visible_from <= ?)
                  and (h.visible_until is null or h.visible_until > ?)
                order by h.sort_order, h.created_at limit 5
                """, this::mapHero, now, now);
    }

    @Transactional(readOnly = true)
    public List<HeroSlideResponse> adminSlides() {
        return jdbc.query(heroSelect() + " where h.deleted_at is null order by h.sort_order, h.created_at", this::mapHero);
    }

    @Transactional
    public HeroSlideResponse createSlide(String actorId, HeroSlideRequest request) {
        validateSlide(request); Instant now = clock.instant(); String id = IdGenerator.newUlid(clock);
        jdbc.update("""
                insert into hero_slides
                (id, desktop_media_id, mobile_media_id, alt_text, eyebrow, title, description, cta_label, cta_path,
                 sort_order, visible_from, visible_until, status, version, created_at, updated_at)
                values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0, ?, ?)
                """, id, request.desktopMediaId(), trim(request.mobileMediaId()), request.altText().trim(), trim(request.eyebrow()),
                request.title().trim(), trim(request.description()), trim(request.ctaLabel()), trim(request.ctaPath()),
                request.sortOrder(), request.visibleFrom(), request.visibleUntil(), request.status().name(), now, now);
        HeroSlideResponse after = slide(id); audit.record(actorId, "HERO_SLIDE_CREATED", "HERO_SLIDE", id, null, after); return after;
    }

    @Transactional
    public HeroSlideResponse updateSlide(String actorId, String id, HeroSlideRequest request) {
        validateSlide(request); HeroSlideResponse before = slide(id); requireVersion(request.version(), before.version(), "HERO_SLIDE_VERSION_CONFLICT");
        int changed = jdbc.update("""
                update hero_slides set desktop_media_id=?, mobile_media_id=?, alt_text=?, eyebrow=?, title=?, description=?,
                cta_label=?, cta_path=?, sort_order=?, visible_from=?, visible_until=?, status=?, version=version+1, updated_at=?
                where id=? and deleted_at is null and version=?
                """, request.desktopMediaId(), trim(request.mobileMediaId()), request.altText().trim(), trim(request.eyebrow()),
                request.title().trim(), trim(request.description()), trim(request.ctaLabel()), trim(request.ctaPath()), request.sortOrder(),
                request.visibleFrom(), request.visibleUntil(), request.status().name(), clock.instant(), id, request.version());
        ensureChanged(changed, "HERO_SLIDE_VERSION_CONFLICT"); HeroSlideResponse after = slide(id);
        audit.record(actorId, "HERO_SLIDE_UPDATED", "HERO_SLIDE", id, before, after); return after;
    }

    @Transactional
    public void deleteSlide(String actorId, String id) {
        HeroSlideResponse before = slide(id); Instant now = clock.instant();
        int changed = jdbc.update("update hero_slides set status='INACTIVE', deleted_at=?, updated_at=?, version=version+1 where id=? and deleted_at is null", now, now, id);
        if (changed == 0) throw new ResourceNotFoundException("HERO_SLIDE_NOT_FOUND", "Không tìm thấy slide");
        audit.record(actorId, "HERO_SLIDE_DELETED", "HERO_SLIDE", id, before, null);
    }

    @Transactional(readOnly = true)
    public List<ProcessStepResponse> publicProcessSteps() {
        return jdbc.query(processSelect() + " where p.status='ACTIVE' and p.deleted_at is null order by p.sort_order, p.created_at", this::mapProcess);
    }

    @Transactional(readOnly = true)
    public List<ProcessStepResponse> adminProcessSteps() {
        return jdbc.query(processSelect() + " where p.deleted_at is null order by p.sort_order, p.created_at", this::mapProcess);
    }

    @Transactional
    public ProcessStepResponse createProcessStep(String actorId, ProcessStepRequest request) {
        validateProcess(request); Instant now = clock.instant(); String id = IdGenerator.newUlid(clock);
        jdbc.update("""
                insert into process_steps
                (id, media_id, title, short_description, long_description, duration_label, alt_text, sort_order, status, version, created_at, updated_at)
                values (?, ?, ?, ?, ?, ?, ?, ?, ?, 0, ?, ?)
                """, id, trim(request.mediaId()), request.title().trim(), request.shortDescription().trim(), request.longDescription().trim(),
                trim(request.duration()), trim(request.altText()), request.sortOrder(), request.status().name(), now, now);
        ProcessStepResponse after = processStep(id); audit.record(actorId, "PROCESS_STEP_CREATED", "PROCESS_STEP", id, null, after); return after;
    }

    @Transactional
    public ProcessStepResponse updateProcessStep(String actorId, String id, ProcessStepRequest request) {
        validateProcess(request); ProcessStepResponse before = processStep(id); requireVersion(request.version(), before.version(), "PROCESS_STEP_VERSION_CONFLICT");
        int changed = jdbc.update("""
                update process_steps set media_id=?, title=?, short_description=?, long_description=?, duration_label=?,
                alt_text=?, sort_order=?, status=?, version=version+1, updated_at=? where id=? and deleted_at is null and version=?
                """, trim(request.mediaId()), request.title().trim(), request.shortDescription().trim(), request.longDescription().trim(),
                trim(request.duration()), trim(request.altText()), request.sortOrder(), request.status().name(), clock.instant(), id, request.version());
        ensureChanged(changed, "PROCESS_STEP_VERSION_CONFLICT"); ProcessStepResponse after = processStep(id);
        audit.record(actorId, "PROCESS_STEP_UPDATED", "PROCESS_STEP", id, before, after); return after;
    }

    @Transactional
    public void deleteProcessStep(String actorId, String id) {
        ProcessStepResponse before = processStep(id); Instant now = clock.instant();
        int changed = jdbc.update("update process_steps set status='INACTIVE', deleted_at=?, updated_at=?, version=version+1 where id=? and deleted_at is null", now, now, id);
        if (changed == 0) throw new ResourceNotFoundException("PROCESS_STEP_NOT_FOUND", "Không tìm thấy bước quy trình");
        audit.record(actorId, "PROCESS_STEP_DELETED", "PROCESS_STEP", id, before, null);
    }

    private SiteSettingsResponse settings(String suffix) {
        try {
            return jdbc.queryForObject("select * from site_settings " + suffix, this::mapSettings);
        } catch (EmptyResultDataAccessException ignored) { return null; }
    }

    private HeroSlideResponse slide(String id) {
        try { return jdbc.queryForObject(heroSelect() + " where h.id=? and h.deleted_at is null", this::mapHero, id); }
        catch (EmptyResultDataAccessException ignored) { throw new ResourceNotFoundException("HERO_SLIDE_NOT_FOUND", "Không tìm thấy slide"); }
    }

    private ProcessStepResponse processStep(String id) {
        try { return jdbc.queryForObject(processSelect() + " where p.id=? and p.deleted_at is null", this::mapProcess, id); }
        catch (EmptyResultDataAccessException ignored) { throw new ResourceNotFoundException("PROCESS_STEP_NOT_FOUND", "Không tìm thấy bước quy trình"); }
    }

    private String heroSelect() {
        return """
                select h.*, desktop.url desktop_url, mobile.url mobile_url
                from hero_slides h join media desktop on desktop.id=h.desktop_media_id
                left join media mobile on mobile.id=h.mobile_media_id
                """;
    }

    private String processSelect() {
        return "select p.*, m.url media_url from process_steps p left join media m on m.id=p.media_id";
    }

    private void validateSettings(SiteSettingsRequest request) {
        validateHttps(request.facebookUrl(), "facebookUrl"); validateHttps(request.tiktokUrl(), "tiktokUrl");
        validateHttps(request.youtubeUrl(), "youtubeUrl"); validateHttps(request.zaloUrl(), "zaloUrl");
        validateHost(request.directionsUrl(), DIRECTIONS_HOSTS, "directionsUrl"); validateHost(request.embedUrl(), GOOGLE_MAP_HOSTS, "embedUrl");
    }

    private void validateSlide(HeroSlideRequest request) {
        requireMedia(request.desktopMediaId()); if (trim(request.mobileMediaId()) != null) requireMedia(request.mobileMediaId());
        if (request.visibleFrom() != null && request.visibleUntil() != null && !request.visibleUntil().isAfter(request.visibleFrom()))
            throw new BadRequestException("HERO_TIME_RANGE_INVALID", "Thời gian kết thúc phải sau thời gian bắt đầu");
        if (trim(request.ctaPath()) != null && (!request.ctaPath().startsWith("/") || request.ctaPath().startsWith("//")))
            throw new BadRequestException("HERO_CTA_PATH_INVALID", "CTA chỉ được dùng đường dẫn nội bộ bắt đầu bằng /");
        if ((trim(request.ctaLabel()) == null) != (trim(request.ctaPath()) == null))
            throw new BadRequestException("HERO_CTA_INCOMPLETE", "Nhãn và đường dẫn CTA phải được cấu hình cùng nhau");
    }

    private void validateProcess(ProcessStepRequest request) { if (trim(request.mediaId()) != null) requireMedia(request.mediaId()); }
    private void requireMedia(String id) { if (jdbc.queryForObject("select count(*) from media where id=?", Integer.class, id) == 0) throw new BadRequestException("MEDIA_NOT_FOUND", "Ảnh được chọn không tồn tại"); }

    private void validateHttps(String value, String field) { if (trim(value) == null) return; URI uri = uri(value, field); if (!"https".equalsIgnoreCase(uri.getScheme()) || uri.getHost() == null) throw invalidUrl(field); }
    private void validateHost(String value, Set<String> hosts, String field) { if (trim(value) == null) return; URI uri = uri(value, field); String host = uri.getHost() == null ? "" : uri.getHost().toLowerCase(Locale.ROOT); if (!"https".equalsIgnoreCase(uri.getScheme()) || !hosts.contains(host)) throw invalidUrl(field); }
    private URI uri(String value, String field) { try { return new URI(value.trim()); } catch (URISyntaxException ignored) { throw invalidUrl(field); } }
    private BadRequestException invalidUrl(String field) { return new BadRequestException("SITE_URL_INVALID", field + " phải là URL HTTPS thuộc miền được phép"); }
    private void requireVersion(Long supplied, long current, String code) { if (supplied == null || supplied != current) throw new ConflictException(code, "Dữ liệu đã thay đổi, vui lòng tải lại trước khi lưu"); }
    private void ensureChanged(int changed, String code) { if (changed == 0) throw new ConflictException(code, "Dữ liệu đã thay đổi, vui lòng tải lại trước khi lưu"); }
    private String trim(String value) { return value == null || value.isBlank() ? null : value.trim(); }
    private Instant instant(ResultSet rs, String column) throws SQLException { Timestamp value = rs.getTimestamp(column); return value == null ? null : value.toInstant(); }

    private SiteSettingsResponse mapSettings(ResultSet rs, int row) throws SQLException {
        return new SiteSettingsResponse(rs.getString("id"), rs.getString("phone"), rs.getString("email"), rs.getString("address"),
                rs.getString("business_hours"), rs.getString("facebook_url"), rs.getString("tiktok_url"), rs.getString("youtube_url"),
                rs.getString("zalo_url"), rs.getString("directions_url"), rs.getString("embed_url"), PublicationStatus.valueOf(rs.getString("status")),
                rs.getLong("version"), instant(rs, "created_at"), instant(rs, "updated_at"));
    }

    private HeroSlideResponse mapHero(ResultSet rs, int row) throws SQLException {
        return new HeroSlideResponse(rs.getString("id"), rs.getString("desktop_media_id"), rs.getString("desktop_url"),
                rs.getString("mobile_media_id"), rs.getString("mobile_url"), rs.getString("alt_text"), rs.getString("eyebrow"),
                rs.getString("title"), rs.getString("description"), rs.getString("cta_label"), rs.getString("cta_path"), rs.getInt("sort_order"),
                instant(rs, "visible_from"), instant(rs, "visible_until"), PublicationStatus.valueOf(rs.getString("status")), rs.getLong("version"),
                instant(rs, "created_at"), instant(rs, "updated_at"));
    }

    private ProcessStepResponse mapProcess(ResultSet rs, int row) throws SQLException {
        return new ProcessStepResponse(rs.getString("id"), rs.getString("media_id"), rs.getString("media_url"), rs.getString("title"),
                rs.getString("short_description"), rs.getString("long_description"), rs.getString("duration_label"), rs.getString("alt_text"),
                rs.getInt("sort_order"), PublicationStatus.valueOf(rs.getString("status")), rs.getLong("version"), instant(rs, "created_at"), instant(rs, "updated_at"));
    }
}
