package com.ruouxunau.sitecontent.api;

import com.ruouxunau.catalog.domain.PublicationStatus;
import java.time.Instant;

public record SiteSettingsResponse(
        String id,
        String phone,
        String email,
        String address,
        String businessHours,
        String facebookUrl,
        String tiktokUrl,
        String youtubeUrl,
        String zaloUrl,
        String directionsUrl,
        String embedUrl,
        PublicationStatus status,
        long version,
        Instant createdAt,
        Instant updatedAt) {
}
