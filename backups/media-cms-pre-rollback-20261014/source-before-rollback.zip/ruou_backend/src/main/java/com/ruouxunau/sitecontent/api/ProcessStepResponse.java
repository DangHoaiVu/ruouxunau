package com.ruouxunau.sitecontent.api;

import com.ruouxunau.catalog.domain.PublicationStatus;
import java.time.Instant;

public record ProcessStepResponse(
        String id,
        String mediaId,
        String imageUrl,
        String title,
        String shortDescription,
        String longDescription,
        String duration,
        String altText,
        int sortOrder,
        PublicationStatus status,
        long version,
        Instant createdAt,
        Instant updatedAt) {
}
