-- Typed storefront content. No sample business content is inserted.

INSERT INTO permissions (id, code, description) VALUES
    ('10000000000000000000000010', 'SITE_CONTENT_MANAGE', 'Quản lý nội dung và cấu hình công khai của website');

INSERT INTO role_permissions (role_id, permission_id)
VALUES ('00000000000000000000000002', '10000000000000000000000010');

CREATE TABLE site_settings (
    id              CHAR(26)      NOT NULL,
    phone           VARCHAR(20)   NULL,
    email           VARCHAR(254)  NULL,
    address         VARCHAR(500)  NULL,
    business_hours  VARCHAR(255)  NULL,
    facebook_url    VARCHAR(2048) NULL,
    tiktok_url      VARCHAR(2048) NULL,
    youtube_url     VARCHAR(2048) NULL,
    zalo_url        VARCHAR(2048) NULL,
    directions_url  VARCHAR(2048) NULL,
    embed_url       VARCHAR(2048) NULL,
    status          VARCHAR(20)   NOT NULL,
    version         BIGINT        NOT NULL DEFAULT 0,
    created_at      TIMESTAMP(6)  NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    updated_at      TIMESTAMP(6)  NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
    PRIMARY KEY (id),
    INDEX idx_site_settings_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE hero_slides (
    id                CHAR(26)      NOT NULL,
    desktop_media_id  CHAR(26)      NOT NULL,
    mobile_media_id   CHAR(26)      NULL,
    alt_text          VARCHAR(255)  NOT NULL,
    eyebrow           VARCHAR(120)  NULL,
    title             VARCHAR(220)  NOT NULL,
    description       VARCHAR(600)  NULL,
    cta_label         VARCHAR(80)   NULL,
    cta_path          VARCHAR(255)  NULL,
    sort_order        INT           NOT NULL DEFAULT 0,
    visible_from      TIMESTAMP(6)  NULL,
    visible_until     TIMESTAMP(6)  NULL,
    status            VARCHAR(20)   NOT NULL,
    version           BIGINT        NOT NULL DEFAULT 0,
    created_at        TIMESTAMP(6)  NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    updated_at        TIMESTAMP(6)  NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
    deleted_at        TIMESTAMP(6)  NULL,
    PRIMARY KEY (id),
    INDEX idx_hero_slides_public (status, visible_from, visible_until, deleted_at, sort_order),
    CONSTRAINT fk_hero_desktop_media FOREIGN KEY (desktop_media_id) REFERENCES media (id),
    CONSTRAINT fk_hero_mobile_media FOREIGN KEY (mobile_media_id) REFERENCES media (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE process_steps (
    id                 CHAR(26)      NOT NULL,
    media_id           CHAR(26)      NULL,
    title              VARCHAR(160)  NOT NULL,
    short_description  VARCHAR(300)  NOT NULL,
    long_description   TEXT          NOT NULL,
    duration_label     VARCHAR(120)  NULL,
    alt_text           VARCHAR(255)  NULL,
    sort_order         INT           NOT NULL DEFAULT 0,
    status             VARCHAR(20)   NOT NULL,
    version            BIGINT        NOT NULL DEFAULT 0,
    created_at         TIMESTAMP(6)  NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    updated_at         TIMESTAMP(6)  NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
    deleted_at         TIMESTAMP(6)  NULL,
    PRIMARY KEY (id),
    INDEX idx_process_steps_public (status, deleted_at, sort_order),
    CONSTRAINT fk_process_step_media FOREIGN KEY (media_id) REFERENCES media (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
