import { HttpInterceptorFn } from '@angular/common/http';
import { inject } from '@angular/core';
import { catchError, switchMap, throwError } from 'rxjs';
import { AuthService } from './auth.service';

export const authInterceptor: HttpInterceptorFn = (request, next) => {
  const auth = inject(AuthService);
  const isAuthEndpoint = request.url.includes('/api/v1/auth/');
  const token = auth.token();
  const authorized = token && !isAuthEndpoint
    ? request.clone({ setHeaders: { Authorization: `Bearer ${token}` }, withCredentials: true })
    : request.clone({ withCredentials: true });

  return next(authorized).pipe(catchError(error => {
    if (error.status !== 401 || isAuthEndpoint || request.headers.has('X-Auth-Retry')) return throwError(() => error);
    return auth.refreshAccess().pipe(switchMap(session => next(request.clone({
      setHeaders: { Authorization: `Bearer ${session.accessToken}`, 'X-Auth-Retry': '1' }, withCredentials: true,
    }))));
  }));
};
