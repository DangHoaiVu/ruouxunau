import { HttpBackend, HttpClient } from '@angular/common/http';
import { Injectable, computed, signal } from '@angular/core';
import { Observable, catchError, finalize, firstValueFrom, map, of, shareReplay, tap, throwError } from 'rxjs';
import { AuthResponse, User } from './models';

@Injectable({ providedIn: 'root' })
export class AuthService {
  private readonly rawHttp: HttpClient;
  private refreshRequest?: Observable<AuthResponse>;
  private readonly accessToken = signal<string | null>(null);
  readonly user = signal<User | null>(null);
  readonly initialized = signal(false);
  readonly busy = signal(false);
  readonly isAuthenticated = computed(() => !!this.user());
  readonly isAdmin = computed(() => this.user()?.permissions.includes('ADMIN_ACCESS') ?? false);

  constructor(handler: HttpBackend) { this.rawHttp = new HttpClient(handler); }

  token(): string | null { return this.accessToken(); }
  hasPermission(permission: string): boolean { return this.user()?.permissions.includes(permission) ?? false; }

  async initialize(): Promise<void> {
    await firstValueFrom(this.refreshAccess().pipe(catchError(() => of(null))));
    this.initialized.set(true);
  }

  login(email: string, password: string): Observable<User> {
    this.busy.set(true);
    return this.rawHttp.post<AuthResponse>('/api/v1/auth/login', { email, password }, { withCredentials: true }).pipe(
      tap(response => this.acceptSession(response)), map(response => response.user), finalize(() => this.busy.set(false)));
  }

  register(fullName: string, email: string, password: string, ageConfirmed: boolean): Observable<User> {
    this.busy.set(true);
    return this.rawHttp.post<AuthResponse>('/api/v1/auth/register', { fullName, email, password, ageConfirmed }, { withCredentials: true }).pipe(
      tap(response => this.acceptSession(response)), map(response => response.user), finalize(() => this.busy.set(false)));
  }

  forgotPassword(email: string): Observable<void> {
    this.busy.set(true);
    return this.rawHttp.post<void>('/api/v1/auth/forgot-password', { email }, { withCredentials: true }).pipe(finalize(() => this.busy.set(false)));
  }

  refreshAccess(): Observable<AuthResponse> {
    if (!this.refreshRequest) {
      this.refreshRequest = this.rawHttp.post<AuthResponse>('/api/v1/auth/refresh', {}, { withCredentials: true }).pipe(
        tap(response => this.acceptSession(response)),
        catchError(error => { this.clearSession(); return throwError(() => error); }),
        finalize(() => { this.refreshRequest = undefined; }),
        shareReplay(1));
    }
    return this.refreshRequest;
  }

  logout(): Observable<void> {
    return this.rawHttp.post<void>('/api/v1/auth/logout', {}, { withCredentials: true }).pipe(finalize(() => this.clearSession()));
  }

  clearSession(): void { this.accessToken.set(null); this.user.set(null); }

  private acceptSession(response: AuthResponse): void {
    this.accessToken.set(response.accessToken);
    this.user.set(response.user);
  }
}
