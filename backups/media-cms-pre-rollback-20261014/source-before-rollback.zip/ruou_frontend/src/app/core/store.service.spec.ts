import { provideHttpClient } from '@angular/common/http';
import { TestBed } from '@angular/core/testing';
import { Product, ProductVariant } from './models';
import { StoreService } from './store.service';

describe('StoreService', () => {
  let store: StoreService;
  const product = { id: 'p1', slug: 'ruou-nep', name: 'Rượu nếp', status: 'ACTIVE', category: { id: 'c1', name: 'Rượu nếp', slug: 'ruou-nep', status: 'ACTIVE', sortOrder: 0 }, variantCount: 1 } as Product;
  const variant = { id: 'v1', productId: 'p1', sku: 'SKU-1', volumeMl: 500, alcoholPercent: 30, price: 250000, weightGram: 700, status: 'ACTIVE', version: 0 } as ProductVariant;

  beforeEach(() => { TestBed.configureTestingModule({ providers: [provideHttpClient()] }); store = TestBed.inject(StoreService); });

  it('removes a cart line when its quantity reaches zero', () => {
    store.cart.set([{ product, variant, quantity: 1 }]);
    store.updateQuantity(variant.id, 0);
    expect(store.cart()).toEqual([]);
  });

  it('does not persist business cart data in localStorage', () => {
    store.cart.set([{ product, variant, quantity: 2 }]);
    expect(localStorage.getItem('ruou-cart')).toBeNull();
  });
});
