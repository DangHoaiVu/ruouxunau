import { HttpErrorResponse } from '@angular/common/http';
import { ProblemDetails } from './models';

export function apiErrorMessage(error: unknown, fallback = 'Không thể kết nối máy chủ. Vui lòng thử lại.'): string {
  if (!(error instanceof HttpErrorResponse)) return fallback;
  const problem = error.error as ProblemDetails | string | null;
  if (typeof problem === 'string' && problem.trim()) return problem;
  if (problem && typeof problem === 'object') {
    const firstFieldError = problem.errors ? Object.values(problem.errors)[0] : undefined;
    return firstFieldError || problem.detail || problem.message || fallback;
  }
  if (error.status === 0) return 'Không kết nối được backend. Hãy kiểm tra Spring Boot đang chạy.';
  if (error.status === 401) return 'Email hoặc mật khẩu không chính xác.';
  if (error.status === 403) return 'Bạn không có quyền thực hiện thao tác này.';
  if (error.status === 429) return 'Bạn thao tác quá nhanh. Vui lòng thử lại sau.';
  return fallback;
}
