import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { AuthService } from './auth.service';

export const authGuard: CanActivateFn = (_, state) => {
  const auth = inject(AuthService); const router = inject(Router);
  return auth.isAuthenticated() || router.createUrlTree(['/dang-nhap'], { queryParams: { returnUrl: state.url } });
};

export const adminGuard: CanActivateFn = () => {
  const auth = inject(AuthService); const router = inject(Router);
  if (!auth.isAuthenticated()) return router.createUrlTree(['/dang-nhap'], { queryParams: { returnUrl: '/admin' } });
  return auth.hasPermission('ADMIN_ACCESS') || router.createUrlTree(['/tai-khoan']);
};
