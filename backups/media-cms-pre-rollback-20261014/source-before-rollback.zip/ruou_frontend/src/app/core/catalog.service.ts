import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable, computed, inject, signal } from '@angular/core';
import { finalize } from 'rxjs';
import { apiErrorMessage } from './api-error';
import { ApiPage, Category, Product } from './models';

@Injectable({ providedIn: 'root' })
export class CatalogService {
  private readonly http = inject(HttpClient);
  readonly products = signal<Product[]>([]);
  readonly categories = signal<Category[]>([]);
  readonly loading = signal(false);
  readonly error = signal('');
  readonly featuredProducts = computed(() => this.products().slice(0, 8));

  load(query = '', category = '', sort = 'newest'): void {
    this.loading.set(true); this.error.set('');
    let params = new HttpParams().set('page', 0).set('size', 100).set('sort', sort);
    if (query.trim()) params = params.set('q', query.trim());
    if (category) params = params.set('category', category);
    this.http.get<ApiPage<Product>>('/api/v1/products', { params }).pipe(finalize(() => this.loading.set(false))).subscribe({
      next: page => this.products.set(page.items), error: error => this.error.set(apiErrorMessage(error, 'Không tải được danh sách sản phẩm.')),
    });
    if (!this.categories().length) this.http.get<Category[]>('/api/v1/categories').subscribe({
      next: categories => this.categories.set(categories), error: error => this.error.set(apiErrorMessage(error, 'Không tải được danh mục sản phẩm.')),
    });
  }

  detail(slug: string) { return this.http.get<Product>(`/api/v1/products/${encodeURIComponent(slug)}`); }
}
