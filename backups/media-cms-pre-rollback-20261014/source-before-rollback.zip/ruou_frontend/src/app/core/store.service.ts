import { DOCUMENT } from '@angular/common';
import { Injectable, computed, inject, signal } from '@angular/core';
import { AuthService } from './auth.service';
import { CartItem, Product, ProductVariant } from './models';

@Injectable({ providedIn: 'root' })
export class StoreService {
  private readonly document = inject(DOCUMENT);
  readonly auth = inject(AuthService);
  readonly user = this.auth.user;
  readonly isAuthenticated = this.auth.isAuthenticated;
  readonly commerceEnabled = false;
  readonly cart = signal<CartItem[]>([]);
  readonly theme = signal<'light' | 'dark'>((localStorage.getItem('ruou-theme') as 'light' | 'dark') ?? 'light');
  readonly ageVerified = signal(localStorage.getItem('ruou-age') === 'yes');
  readonly toast = signal('');
  readonly cartCount = computed(() => this.cart().reduce((sum, item) => sum + item.quantity, 0));
  readonly subtotal = computed(() => this.cart().reduce((sum, item) => sum + item.variant.price * item.quantity, 0));

  constructor() { this.applyTheme(); }

  confirmAge(): void { localStorage.setItem('ruou-age', 'yes'); this.ageVerified.set(true); }
  toggleTheme(): void { this.theme.update(value => value === 'light' ? 'dark' : 'light'); localStorage.setItem('ruou-theme', this.theme()); this.applyTheme(); }

  addToCart(product: Product, variant: ProductVariant, quantity = 1): boolean {
    if (!this.isAuthenticated()) return false;
    if (!this.commerceEnabled) { this.notify('Giỏ hàng sẽ mở sau khi API tồn kho và giữ tồn hoàn tất nghiệm thu.'); return true; }
    const safeQuantity = Math.max(1, quantity);
    const existing = this.cart().find(item => item.variant.id === variant.id);
    const items = existing
      ? this.cart().map(item => item.variant.id === variant.id ? { ...item, quantity: item.quantity + safeQuantity } : item)
      : [...this.cart(), { product, variant, quantity: safeQuantity }];
    this.cart.set(items);
    this.notify(`Đã thêm ${product.name} vào giỏ`);
    return true;
  }

  updateQuantity(variantId: string, quantity: number): void {
    if (quantity <= 0) { this.removeFromCart(variantId); return; }
    this.cart.update(items => items.map(item => item.variant.id === variantId ? { ...item, quantity } : item));
  }

  removeFromCart(variantId: string): void {
    this.cart.update(items => items.filter(item => item.variant.id !== variantId));
    this.notify('Đã xóa sản phẩm khỏi giỏ');
  }

  notify(message: string): void {
    this.toast.set(message);
    window.setTimeout(() => { if (this.toast() === message) this.toast.set(''); }, 3200);
  }

  formatPrice(price?: number): string {
    if (price == null) return 'Liên hệ';
    return new Intl.NumberFormat('vi-VN', { style: 'currency', currency: 'VND' }).format(price);
  }

  private applyTheme(): void { this.document.documentElement.dataset['theme'] = this.theme(); }
}
