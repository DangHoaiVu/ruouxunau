import { HttpClient } from '@angular/common/http';
import { Injectable, inject, signal } from '@angular/core';
import { finalize } from 'rxjs';
import { apiErrorMessage } from './api-error';
import { ApiPage, ArticleCategory, Story } from './models';

@Injectable({ providedIn: 'root' })
export class ContentService {
  private readonly http = inject(HttpClient);
  readonly stories = signal<Story[]>([]);
  readonly categories = signal<ArticleCategory[]>([]);
  readonly loading = signal(false);
  readonly error = signal('');

  load(): void {
    this.loading.set(true); this.error.set('');
    this.http.get<ApiPage<Story>>('/api/v1/articles', { params: { page: 0, size: 100, sort: 'newest' } }).pipe(finalize(() => this.loading.set(false))).subscribe({
      next: page => this.stories.set(page.items), error: error => this.error.set(apiErrorMessage(error, 'Không tải được bài viết.')),
    });
    if (!this.categories().length) this.http.get<ArticleCategory[]>('/api/v1/article-categories').subscribe({
      next: categories => this.categories.set(categories), error: error => this.error.set(apiErrorMessage(error, 'Không tải được chuyên mục.')),
    });
  }

  detail(slug: string) { return this.http.get<Story>(`/api/v1/articles/${encodeURIComponent(slug)}`); }
}
