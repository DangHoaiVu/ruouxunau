export interface ApiPage<T> {
  items: T[];
  page: number;
  size: number;
  totalElements: number;
  totalPages: number;
}

export interface Category {
  id: string;
  name: string;
  slug: string;
  description?: string;
  status: string;
  sortOrder: number;
}

export interface ProductVariant {
  id: string;
  productId: string;
  sku: string;
  barcode?: string;
  volumeMl: number;
  alcoholPercent: number;
  price: number;
  comparePrice?: number;
  weightGram: number;
  status: string;
  version: number;
}

export interface ProductImage {
  mediaId: string;
  url: string;
  altText: string;
  width?: number;
  height?: number;
  sortOrder: number;
  primary: boolean;
}

export interface Product {
  id: string;
  slug: string;
  name: string;
  shortDescription?: string;
  description?: string;
  storageInstructions?: string;
  origin?: string;
  status: string;
  category: Category;
  producer?: { id: string; name: string; origin?: string };
  minPrice?: number;
  maxPrice?: number;
  variantCount: number;
  primaryImageUrl?: string;
  variants?: ProductVariant[];
  images?: ProductImage[];
}

export interface ArticleCategory {
  id: string;
  name: string;
  slug: string;
  description?: string;
  status: string;
  sortOrder: number;
}

export interface Story {
  id: string;
  slug: string;
  title: string;
  excerpt: string;
  content?: string;
  status: string;
  category: ArticleCategory;
  featuredMedia?: { id: string; url: string; altText: string };
  authorId: string;
  authorName: string;
  publishedAt: string;
}

export interface User {
  id: string;
  email: string;
  fullName: string;
  phone?: string;
  roles: string[];
  permissions: string[];
}

export interface AuthResponse {
  tokenType: 'Bearer';
  accessToken: string;
  accessTokenExpiresAt: string;
  user: User;
}

export interface ProblemDetails {
  status?: number;
  code?: string;
  detail?: string;
  message?: string;
  errors?: Record<string, string>;
}

export interface SiteSettings {
  id: string;
  phone?: string;
  email?: string;
  address?: string;
  businessHours?: string;
  facebookUrl?: string;
  tiktokUrl?: string;
  youtubeUrl?: string;
  zaloUrl?: string;
  directionsUrl?: string;
  embedUrl?: string;
  status: 'DRAFT' | 'ACTIVE' | 'INACTIVE';
  version: number;
}

export interface HeroSlide {
  id: string;
  desktopMediaId: string;
  desktopImageUrl: string;
  mobileMediaId?: string;
  mobileImageUrl?: string;
  altText: string;
  eyebrow?: string;
  title: string;
  description?: string;
  ctaLabel?: string;
  ctaPath?: string;
  sortOrder: number;
  status: 'DRAFT' | 'ACTIVE' | 'INACTIVE';
  version: number;
}

export interface ProcessStep {
  id: string;
  mediaId?: string;
  title: string;
  shortDescription: string;
  longDescription: string;
  duration?: string;
  imageUrl?: string;
  altText?: string;
  sortOrder: number;
  status: 'DRAFT' | 'ACTIVE' | 'INACTIVE';
  version: number;
}

export interface CartItem {
  product: Product;
  variant: ProductVariant;
  quantity: number;
}
