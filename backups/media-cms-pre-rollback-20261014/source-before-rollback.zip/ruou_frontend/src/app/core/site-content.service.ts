import { HttpClient } from '@angular/common/http';
import { Injectable, inject, signal } from '@angular/core';
import { forkJoin, of } from 'rxjs';
import { catchError, finalize } from 'rxjs/operators';
import { apiErrorMessage } from './api-error';
import { HeroSlide, ProcessStep, SiteSettings } from './models';

@Injectable({ providedIn: 'root' })
export class SiteContentService {
  private readonly http = inject(HttpClient);
  readonly settings = signal<SiteSettings | null>(null);
  readonly slides = signal<HeroSlide[]>([]);
  readonly processSteps = signal<ProcessStep[]>([]);
  readonly loading = signal(false);
  readonly error = signal('');

  load(): void {
    this.loading.set(true); this.error.set('');
    forkJoin({
      settings: this.http.get<SiteSettings>('/api/v1/site-settings').pipe(catchError(() => of(null))),
      slides: this.http.get<HeroSlide[]>('/api/v1/hero-slides').pipe(catchError(() => of([]))),
      processSteps: this.http.get<ProcessStep[]>('/api/v1/process-steps').pipe(catchError(() => of([]))),
    }).pipe(finalize(() => this.loading.set(false))).subscribe({
      next: result => { this.settings.set(result.settings); this.slides.set(result.slides); this.processSteps.set(result.processSteps); },
      error: error => this.error.set(apiErrorMessage(error, 'Không tải được nội dung website.')),
    });
  }
}
