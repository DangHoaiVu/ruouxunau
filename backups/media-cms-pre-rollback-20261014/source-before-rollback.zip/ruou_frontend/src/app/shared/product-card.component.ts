import { Component, inject, input } from '@angular/core';
import { RouterLink } from '@angular/router';
import { Product } from '../core/models';
import { StoreService } from '../core/store.service';

@Component({
  selector: 'app-product-card', imports: [RouterLink],
  template: `
    <article class="product-card">
      <a class="product-image" [routerLink]="['/san-pham', product().slug]">
        @if (product().primaryImageUrl) { <img [src]="product().primaryImageUrl" [alt]="product().name" loading="lazy" /> }
        @else { <span class="image-placeholder" aria-hidden="true">Rượu Xứ Nẫu</span> }
      </a>
      <div class="product-body">
        <p class="eyebrow">{{ product().category.name }} · {{ product().variantCount }} lựa chọn</p>
        <h3><a [routerLink]="['/san-pham', product().slug]">{{ product().name }}</a></h3>
        <p class="product-description">{{ product().shortDescription || 'Thông tin sản phẩm đang được cập nhật.' }}</p>
        <div class="product-footer"><div><strong>{{ priceLabel() }}</strong></div><a class="add-button" [routerLink]="['/san-pham', product().slug]" aria-label="Xem chi tiết sản phẩm">→</a></div>
      </div>
    </article>
  `,
})
export class ProductCardComponent {
  readonly product = input.required<Product>();
  readonly store = inject(StoreService);
  priceLabel(): string {
    const product = this.product();
    if (product.minPrice == null) return 'Liên hệ';
    if (product.maxPrice != null && product.maxPrice !== product.minPrice) return `Từ ${this.store.formatPrice(product.minPrice)}`;
    return this.store.formatPrice(product.minPrice);
  }
}
