import { Component, OnInit, inject, signal } from '@angular/core';
import { RouterLink } from '@angular/router';
import { ContentService } from '../core/content.service';

@Component({
  selector: 'app-stories', imports: [RouterLink],
  template: `
    <section class="editorial-hero"><div class="container"><p class="eyebrow">Tạp chí Xứ Nẫu</p><h1>Chuyện của đất,<br /><em>người và men rượu.</em></h1><p>Những nội dung đã được quản trị viên duyệt và xuất bản.</p></div></section>
    @if (featured(); as article) { <section class="container featured-story"><a [routerLink]="['/cau-chuyen', article.slug]" class="featured-story-image">@if (article.featuredMedia?.url) { <img [src]="article.featuredMedia!.url" [alt]="article.featuredMedia!.altText || article.title" /> } @else { <span class="image-placeholder">Tạp chí Xứ Nẫu</span> }<span>Bài mới nhất</span></a><div><p class="eyebrow">{{ article.category.name }} · {{ formatDate(article.publishedAt) }}</p><h2><a [routerLink]="['/cau-chuyen', article.slug]">{{ article.title }}</a></h2><p>{{ article.excerpt }}</p><a class="arrow-link" [routerLink]="['/cau-chuyen', article.slug]">Đọc câu chuyện <span>→</span></a></div></section> }
    <section class="section container"><div class="story-categories"><button type="button" [class.active]="selectedCategory() === ''" (click)="selectedCategory.set('')">Tất cả</button>@for (category of content.categories(); track category.id) { <button type="button" [class.active]="selectedCategory() === category.slug" (click)="selectedCategory.set(category.slug)">{{ category.name }}</button> }</div>
      @if (content.loading()) { <div class="loading-state" role="status">Đang tải bài viết…</div> }
      @else if (content.error()) { <div class="empty-state error-state"><h2>Chưa tải được bài viết</h2><p>{{ content.error() }}</p><button class="button button-secondary" type="button" (click)="content.load()">Thử lại</button></div> }
      @else { <div class="story-grid large">@for (story of filteredStories(); track story.id) { <article class="story-card"><a [routerLink]="['/cau-chuyen', story.slug]">@if (story.featuredMedia?.url) { <img [src]="story.featuredMedia!.url" [alt]="story.featuredMedia!.altText || story.title" loading="lazy" /> } @else { <span class="image-placeholder">Tạp chí Xứ Nẫu</span> }</a><p class="eyebrow">{{ story.category.name }}</p><h3><a [routerLink]="['/cau-chuyen', story.slug]">{{ story.title }}</a></h3><p>{{ story.excerpt }}</p><small>{{ story.authorName }} · {{ formatDate(story.publishedAt) }}</small></article> } @empty { <div class="empty-state"><h2>Chưa có bài viết đã xuất bản</h2><p>Nội dung sẽ xuất hiện sau khi được quản trị viên duyệt.</p></div> }</div> }
    </section>
  `,
})
export class StoriesComponent implements OnInit {
  readonly content = inject(ContentService); readonly selectedCategory = signal('');
  ngOnInit(): void { this.content.load(); }
  featured() { return this.content.stories()[0] ?? null; }
  filteredStories() { const category = this.selectedCategory(); return category ? this.content.stories().filter(story => story.category.slug === category) : this.content.stories(); }
  formatDate(value: string): string { return value ? new Intl.DateTimeFormat('vi-VN', { dateStyle: 'medium' }).format(new Date(value)) : ''; }
}
