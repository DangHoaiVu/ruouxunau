import { Component, OnInit, computed, inject, signal } from '@angular/core';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { apiErrorMessage } from '../core/api-error';
import { CatalogService } from '../core/catalog.service';
import { Product, ProductVariant } from '../core/models';
import { StoreService } from '../core/store.service';
import { ProductCardComponent } from '../shared/product-card.component';

@Component({
  selector: 'app-product-detail', imports: [RouterLink, ProductCardComponent],
  template: `
    @if (loading()) { <section class="section loading-state" role="status">Đang tải sản phẩm…</section> }
    @else if (product(); as item) {
      <section class="product-detail section container">
        <div class="breadcrumbs"><a routerLink="/">Trang chủ</a><span>/</span><a routerLink="/san-pham">Sản phẩm</a><span>/</span><span>{{ item.name }}</span></div>
        <div class="product-detail-grid"><div class="gallery"><div class="main-image">@if (selectedImage()) { <img [src]="selectedImage()" [alt]="item.name" /> } @else { <span class="image-placeholder">Rượu Xứ Nẫu</span> }</div>@if ((item.images?.length ?? 0) > 1) { <div class="thumbnails">@for (image of item.images; track image.mediaId) { <button type="button" [class.active]="selectedImage() === image.url" (click)="selectedImage.set(image.url)"><img [src]="image.url" [alt]="image.altText" /></button> }</div> }</div>
        <div class="product-info"><p class="eyebrow">{{ item.category.name }}</p><h1>{{ item.name }}</h1><p class="lead">{{ item.shortDescription }}</p>
          @if (selectedVariant(); as variant) { <div class="detail-price"><strong>{{ store.formatPrice(variant.price) }}</strong>@if (variant.comparePrice) { <del>{{ store.formatPrice(variant.comparePrice) }}</del> }</div> }
          @if ((item.variants?.length ?? 0) > 1) { <label class="variant-select">Lựa chọn<select (change)="selectVariant($event)">@for (variant of item.variants; track variant.id) { <option [value]="variant.id">{{ variant.volumeMl }} ml · {{ variant.alcoholPercent }}% · {{ store.formatPrice(variant.price) }}</option> }</select></label> }
          @if (selectedVariant(); as variant) { <div class="spec-grid"><div><small>Dung tích</small><strong>{{ variant.volumeMl }} ml</strong></div><div><small>Nồng độ</small><strong>{{ variant.alcoholPercent }}% vol</strong></div><div><small>Mã SKU</small><strong>{{ variant.sku }}</strong></div><div><small>Xuất xứ</small><strong>{{ item.origin || 'Đang cập nhật' }}</strong></div></div> }
          <div class="buy-row"><button class="button button-primary grow" type="button" [disabled]="!store.commerceEnabled || !selectedVariant()" (click)="add(item)">{{ store.commerceEnabled ? 'Thêm vào giỏ' : 'Mở bán sau khi hoàn tất kiểm kê' }}</button></div>
          @if (!store.commerceEnabled) { <p class="integration-note">Giá được lấy từ Catalog API. Chức năng mua hàng đang khóa có chủ đích đến khi API tồn kho và giữ tồn hoàn tất nghiệm thu.</p> }
        </div></div>
      </section>
      <section class="detail-story section"><div class="container two-column"><div><p class="eyebrow">Câu chuyện sản phẩm</p><h2>Chắt lọc từ<br />hạt gạo và thời gian.</h2></div><div><p>{{ item.description }}</p><dl><div><dt>Cơ sở sản xuất</dt><dd>{{ item.producer?.name || 'Đang cập nhật' }}</dd></div><div><dt>Nguồn gốc</dt><dd>{{ item.origin || 'Đang cập nhật' }}</dd></div><div><dt>Bảo quản</dt><dd>{{ item.storageInstructions || 'Nơi khô ráo, tránh ánh nắng trực tiếp' }}</dd></div></dl><p class="responsible">Sản phẩm dành cho người đủ 18 tuổi. Không lái xe sau khi sử dụng đồ uống có cồn.</p></div></div></section>
      @if (relatedProducts().length) { <section class="section container"><div class="section-heading"><div><p class="eyebrow">Gợi ý tiếp theo</p><h2>Có thể bạn sẽ thích</h2></div></div><div class="product-grid related">@for (related of relatedProducts(); track related.id) { <app-product-card [product]="related" /> }</div></section> }
    } @else { <section class="section empty-state"><h1>Không tìm thấy sản phẩm</h1><p>{{ error() }}</p><a class="button button-primary" routerLink="/san-pham">Về bộ sưu tập</a></section> }
  `,
})
export class ProductDetailComponent implements OnInit {
  readonly store = inject(StoreService); private readonly catalog = inject(CatalogService); private readonly router = inject(Router); private readonly route = inject(ActivatedRoute);
  readonly product = signal<Product | null>(null); readonly selectedVariant = signal<ProductVariant | null>(null); readonly selectedImage = signal(''); readonly loading = signal(true); readonly error = signal('');
  readonly relatedProducts = computed(() => this.catalog.products().filter(item => item.id !== this.product()?.id).slice(0, 3));
  ngOnInit(): void {
    if (!this.catalog.products().length) this.catalog.load();
    const slug = this.route.snapshot.paramMap.get('slug') ?? '';
    this.catalog.detail(slug).subscribe({
      next: product => { this.product.set(product); this.selectedVariant.set(product.variants?.[0] ?? null); this.selectedImage.set(product.images?.find(image => image.primary)?.url ?? product.images?.[0]?.url ?? product.primaryImageUrl ?? ''); this.loading.set(false); },
      error: error => { this.error.set(apiErrorMessage(error, 'Sản phẩm không tồn tại hoặc chưa được công bố.')); this.loading.set(false); },
    });
  }
  selectVariant(event: Event): void { const id = (event.target as HTMLSelectElement).value; this.selectedVariant.set(this.product()?.variants?.find(item => item.id === id) ?? null); }
  add(product: Product): void {
    const variant = this.selectedVariant(); if (!variant) return;
    if (!this.store.addToCart(product, variant)) this.router.navigate(['/dang-nhap'], { queryParams: { returnUrl: this.router.url } });
  }
}
