import { Component, DestroyRef, ElementRef, OnInit, ViewChild, effect, inject, signal } from '@angular/core';
import { RouterLink } from '@angular/router';
import { CatalogService } from '../core/catalog.service';
import { ContentService } from '../core/content.service';
import { HeroSlide, ProcessStep } from '../core/models';
import { SiteContentService } from '../core/site-content.service';
import { ProductCardComponent } from '../shared/product-card.component';

@Component({
  selector: 'app-home', imports: [RouterLink, ProductCardComponent],
  template: `
    <section class="hero hero-slider" (mouseenter)="paused.set(true)" (mouseleave)="paused.set(false)" (focusin)="paused.set(true)" (focusout)="paused.set(false)">
      @if (activeSlide(); as slide) { <picture class="hero-media">@if (slide.mobileImageUrl) { <source media="(max-width: 640px)" [srcset]="slide.mobileImageUrl" /> }<img [src]="slide.desktopImageUrl" [alt]="slide.altText" /></picture> }
      <div class="hero-overlay"></div>
      <div class="hero-content container reveal"><p class="eyebrow light">{{ activeSlide()?.eyebrow || 'Từ miền đất võ Bình Định' }}</p><h1>{{ activeSlide()?.title || 'Giọt nồng kể chuyện quê.' }}</h1><p>{{ activeSlide()?.description || 'Rượu thủ công từ hạt gạo Việt, gìn giữ bằng bàn tay người thợ và được kể lại trong một dáng hình đương đại.' }}</p><div class="hero-actions">@if (activeSlide()?.ctaLabel && activeSlide()?.ctaPath) { <a class="button button-primary" [routerLink]="activeSlide()!.ctaPath">{{ activeSlide()!.ctaLabel }}</a> } @else { <a class="button button-primary" routerLink="/san-pham">Khám phá bộ sưu tập</a> }<a class="button button-ghost" routerLink="/cau-chuyen">Đọc chuyện làng nghề</a></div></div>
      @if (site.slides().length > 1) { <div class="slider-controls" aria-label="Điều khiển trình chiếu"><button type="button" (click)="previousSlide()" aria-label="Slide trước">←</button><span>{{ activeIndex() + 1 }} / {{ site.slides().length }}</span><button type="button" (click)="nextSlide()" aria-label="Slide sau">→</button><button type="button" (click)="paused.set(!paused())" [attr.aria-label]="paused() ? 'Tiếp tục trình chiếu' : 'Tạm dừng trình chiếu'">{{ paused() ? 'Phát' : 'Dừng' }}</button></div> }
      <a class="scroll-cue" href="#featured">Cuộn để khám phá <span>↓</span></a>
    </section>

    <section class="intro section container"><div><p class="eyebrow">Một thức quà từ Xứ Nẫu</p><h2 class="display-title">Không chỉ là vị rượu.<br />Đó là ký ức của một miền đất.</h2></div><div class="intro-copy"><p>Dữ liệu sản phẩm và câu chuyện trên website được công bố từ hệ thống quản trị, không sử dụng dữ liệu mẫu phía trình duyệt.</p><a class="arrow-link" routerLink="/cau-chuyen">Xem những câu chuyện đã xuất bản <span>→</span></a></div></section>

    <section id="featured" class="section featured-section"><div class="container section-heading"><div><p class="eyebrow">Bộ sưu tập</p><h2>Chọn một hương vị riêng</h2></div><a class="arrow-link" routerLink="/san-pham">Xem tất cả <span>→</span></a></div>
      @if (catalog.loading()) { <div class="container loading-state">Đang tải sản phẩm…</div> }
      @else if (catalog.error()) { <div class="container empty-state error-state"><p>{{ catalog.error() }}</p><button class="button button-secondary" type="button" (click)="catalog.load()">Thử lại</button></div> }
      @else if (catalog.featuredProducts().length) { <div class="product-marquee" [class.static-list]="catalog.featuredProducts().length < 5"><div class="marquee-track">@for (product of catalog.featuredProducts(); track product.id) { <app-product-card [product]="product" /> }</div></div> }
      @else { <div class="container empty-state"><h3>Chưa có sản phẩm đã công bố</h3><p>Sản phẩm sẽ xuất hiện sau khi quản trị viên hoàn tất nội dung và biến thể.</p></div> }
    </section>

    @if (site.processSteps().length) { <section class="craft-section section"><div class="craft-copy full-process"><p class="eyebrow light">Kỹ nghệ & thời gian</p><h2>Một mẻ rượu,<br />nhiều lần nâng niu.</h2><div class="process-list pack-grid">@for (step of site.processSteps(); track step.id; let index = $index) { <button type="button" class="process-pack" (click)="openStep(step)"><span>{{ (index + 1).toString().padStart(2, '0') }}</span><h3>{{ step.title }}</h3><p>{{ step.shortDescription }}</p><small>Xem chi tiết →</small></button> }</div></div></section> }

    <section class="section stories-preview container"><div class="section-heading"><div><p class="eyebrow">Tạp chí Xứ Nẫu</p><h2>Chuyện bên ché rượu</h2></div><a class="arrow-link" routerLink="/cau-chuyen">Đọc tất cả <span>→</span></a></div>
      @if (content.loading()) { <div class="loading-state">Đang tải bài viết…</div> }
      @else if (content.error()) { <div class="empty-state error-state"><p>{{ content.error() }}</p><button class="button button-secondary" type="button" (click)="content.load()">Thử lại</button></div> }
      @else { <div class="story-marquee"><div class="story-track">@for (story of content.stories().slice(0, 8); track story.id) { <article class="story-card"><a [routerLink]="['/cau-chuyen', story.slug]">@if (story.featuredMedia?.url) { <img [src]="story.featuredMedia!.url" [alt]="story.featuredMedia!.altText || story.title" loading="lazy" /> } @else { <span class="image-placeholder">Tạp chí Xứ Nẫu</span> }</a><p class="eyebrow">{{ story.category.name }}</p><h3><a [routerLink]="['/cau-chuyen', story.slug]">{{ story.title }}</a></h3><p>{{ story.excerpt }}</p></article> } @empty { <div class="empty-state"><h3>Chưa có bài viết đã xuất bản</h3></div> }</div></div> }
    </section>

    <dialog #processDialog class="process-dialog" (close)="selectedStep.set(null)">@if (selectedStep(); as step) { <button type="button" class="dialog-close" (click)="closeStep()" aria-label="Đóng">×</button>@if (step.imageUrl) { <img [src]="step.imageUrl" [alt]="step.altText || step.title" /> }<p class="eyebrow">Quy trình sản xuất</p><h2>{{ step.title }}</h2><p>{{ step.longDescription }}</p>@if (step.duration) { <strong>Thời gian: {{ step.duration }}</strong> }<div class="dialog-nav"><button type="button" (click)="moveStep(-1)" [disabled]="stepIndex() === 0">← Bước trước</button><button type="button" (click)="moveStep(1)" [disabled]="stepIndex() === site.processSteps().length - 1">Bước sau →</button></div> }</dialog>
  `,
})
export class HomeComponent implements OnInit {
  readonly catalog = inject(CatalogService); readonly content = inject(ContentService); readonly site = inject(SiteContentService); private readonly destroyRef = inject(DestroyRef);
  readonly activeIndex = signal(0); readonly paused = signal(false); readonly selectedStep = signal<ProcessStep | null>(null);
  @ViewChild('processDialog') processDialog?: ElementRef<HTMLDialogElement>;
  private timer?: number;

  constructor() {
    effect(() => {
      const count = this.site.slides().length; this.stopTimer();
      if (count > 1 && !this.reducedMotion()) this.timer = window.setInterval(() => { if (!this.paused()) this.nextSlide(); }, 6000);
    });
    this.destroyRef.onDestroy(() => this.stopTimer());
  }
  ngOnInit(): void { this.catalog.load(); this.content.load(); this.site.load(); }
  activeSlide(): HeroSlide | null { return this.site.slides()[this.activeIndex()] ?? null; }
  nextSlide(): void { const count = this.site.slides().length; if (count) this.activeIndex.update(index => (index + 1) % count); }
  previousSlide(): void { const count = this.site.slides().length; if (count) this.activeIndex.update(index => (index - 1 + count) % count); }
  openStep(step: ProcessStep): void { this.selectedStep.set(step); this.processDialog?.nativeElement.showModal(); }
  closeStep(): void { this.processDialog?.nativeElement.close(); }
  stepIndex(): number { return this.site.processSteps().findIndex(step => step.id === this.selectedStep()?.id); }
  moveStep(delta: number): void { const next = this.site.processSteps()[this.stepIndex() + delta]; if (next) this.selectedStep.set(next); }
  private stopTimer(): void { if (this.timer) window.clearInterval(this.timer); this.timer = undefined; }
  private reducedMotion(): boolean { return window.matchMedia('(prefers-reduced-motion: reduce)').matches; }
}
