import { HttpClient } from '@angular/common/http';
import { Component, OnInit, inject, signal } from '@angular/core';
import { Router, RouterLink } from '@angular/router';
import { apiErrorMessage } from '../core/api-error';
import { AuthService } from '../core/auth.service';
import { StoreService } from '../core/store.service';

interface Address { id: string; receiverName: string; phone: string; provinceName: string; districtName: string; wardName: string; detail: string; defaultAddress: boolean; }

@Component({
  selector: 'app-account', imports: [RouterLink],
  template: `
    <section class="page-hero mini"><div class="container"><p class="eyebrow light">Tài khoản</p><h1>Xin chào, {{ auth.user()?.fullName }}</h1></div></section>
    <section class="section container account-layout"><aside class="account-nav">@for (tab of tabs; track tab.id) { <button type="button" [class.active]="activeTab() === tab.id" (click)="activeTab.set(tab.id)">{{ tab.label }}</button> }@if (auth.isAdmin()) { <a class="admin-link" routerLink="/admin">Mở trang quản trị ↗</a> }<button type="button" class="logout" (click)="logout()">Đăng xuất</button></aside>
      <div class="account-content">
        @if (activeTab() === 'overview') { <div class="welcome-card"><p class="eyebrow">Thành viên Xứ Nẫu</p><h2>{{ auth.user()?.fullName }}</h2><p>{{ auth.user()?.email }}</p></div><section class="account-panel"><h2>Trạng thái tài khoản</h2><p>Phiên đăng nhập đang dùng access token ngắn hạn và refresh cookie HttpOnly. Vai trò/quyền được cấp bởi backend.</p><div class="permission-list">@for (role of auth.user()?.roles ?? []; track role) { <span>{{ role }}</span> }</div></section> }
        @if (activeTab() === 'orders') { <section class="account-panel"><p class="eyebrow">Lịch sử mua hàng</p><h2>Đơn hàng của tôi</h2><div class="empty-state compact"><h3>Chức năng đang được khóa an toàn</h3><p>Đơn hàng chỉ được mở sau khi các module tồn kho, giỏ hàng, thanh toán và vận chuyển hoàn tất nghiệm thu.</p></div></section> }
        @if (activeTab() === 'addresses') { <section class="account-panel"><p class="eyebrow">Sổ địa chỉ</p><h2>Địa chỉ nhận hàng</h2>@if (addressesLoading()) { <div class="loading-state">Đang tải địa chỉ…</div> } @else if (addressesError()) { <div class="empty-state error-state"><p>{{ addressesError() }}</p><button class="button button-secondary" type="button" (click)="loadAddresses()">Thử lại</button></div> } @else { <div class="address-list">@for (address of addresses(); track address.id) { <article><strong>{{ address.receiverName }} · {{ address.phone }}</strong><p>{{ address.detail }}, {{ address.wardName }}, {{ address.districtName }}, {{ address.provinceName }}</p>@if (address.defaultAddress) { <span>Mặc định</span> }</article> } @empty { <div class="empty-state compact"><h3>Chưa có địa chỉ đã lưu</h3><p>Địa chỉ sẽ được thêm trong quy trình hồ sơ/checkout sau khi biểu mẫu địa giới được kết nối.</p></div> }</div> }</section> }
        @if (activeTab() === 'profile') { <section class="account-panel"><p class="eyebrow">Hồ sơ</p><h2>Thông tin cá nhân</h2><dl class="profile-list"><div><dt>Họ tên</dt><dd>{{ auth.user()?.fullName }}</dd></div><div><dt>Email</dt><dd>{{ auth.user()?.email }}</dd></div><div><dt>Số điện thoại</dt><dd>{{ auth.user()?.phone || 'Chưa cập nhật' }}</dd></div><div><dt>Vai trò</dt><dd>{{ (auth.user()?.roles ?? []).join(', ') }}</dd></div></dl></section> }
      </div>
    </section>
  `,
})
export class AccountComponent implements OnInit {
  readonly auth = inject(AuthService); readonly store = inject(StoreService); private readonly http = inject(HttpClient); private readonly router = inject(Router);
  readonly tabs = [{ id: 'overview', label: 'Tổng quan' }, { id: 'orders', label: 'Đơn hàng' }, { id: 'addresses', label: 'Địa chỉ' }, { id: 'profile', label: 'Thông tin cá nhân' }]; readonly activeTab = signal('overview');
  readonly addresses = signal<Address[]>([]); readonly addressesLoading = signal(false); readonly addressesError = signal('');
  ngOnInit(): void { this.loadAddresses(); }
  loadAddresses(): void { this.addressesLoading.set(true); this.addressesError.set(''); this.http.get<Address[]>('/api/v1/me/addresses').subscribe({ next: value => { this.addresses.set(value); this.addressesLoading.set(false); }, error: error => { this.addressesError.set(apiErrorMessage(error, 'Không tải được địa chỉ.')); this.addressesLoading.set(false); } }); }
  logout(): void { this.auth.logout().subscribe({ next: () => { this.store.notify('Bạn đã đăng xuất'); this.router.navigateByUrl('/'); }, error: () => { this.auth.clearSession(); this.router.navigateByUrl('/'); } }); }
}
