import { Component, OnInit, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { CatalogService } from '../core/catalog.service';
import { ProductCardComponent } from '../shared/product-card.component';

@Component({
  selector: 'app-products', imports: [FormsModule, ProductCardComponent],
  template: `
    <section class="page-hero compact"><div class="container"><p class="eyebrow light">Bộ sưu tập Xứ Nẫu</p><h1>Chọn vị rượu<br /><em>hợp với câu chuyện.</em></h1><p>Sản phẩm công khai được tải trực tiếp từ hệ thống quản trị.</p></div></section>
    <section class="catalog section container">
      <div class="catalog-toolbar"><div><strong>{{ filtered().length }}</strong> sản phẩm</div><button class="filter-toggle" type="button" (click)="filterOpen.set(!filterOpen())" [attr.aria-expanded]="filterOpen()">Bộ lọc <span>⚙</span></button><label class="sr-only" for="catalog-sort">Sắp xếp</label><select id="catalog-sort" [(ngModel)]="sort"><option value="newest">Mới nhất</option><option value="price-asc">Giá tăng dần</option><option value="price-desc">Giá giảm dần</option></select></div>
      <div class="catalog-layout">
        <aside class="filters" [class.open]="filterOpen()"><div class="filter-head"><h3>Bộ lọc</h3><button type="button" (click)="resetFilters()">Đặt lại</button></div><label>Tìm kiếm<input [(ngModel)]="query" placeholder="Tên sản phẩm..." /></label><label>Dòng rượu<select [(ngModel)]="category"><option value="">Tất cả</option>@for (item of catalog.categories(); track item.id) { <option [value]="item.slug">{{ item.name }}</option> }</select></label><label>Khoảng giá<select [(ngModel)]="priceRange"><option value="">Tất cả mức giá</option><option value="300">Dưới 300.000đ</option><option value="500">300.000đ – 500.000đ</option><option value="501">Trên 500.000đ</option></select></label></aside>
        <div class="product-grid">
          @if (catalog.loading()) { <div class="loading-state" role="status">Đang tải bộ sưu tập…</div> }
          @else if (catalog.error()) { <div class="empty-state error-state"><h2>Chưa tải được sản phẩm</h2><p>{{ catalog.error() }}</p><button class="button button-secondary" type="button" (click)="catalog.load()">Thử lại</button></div> }
          @else { @for (product of filtered(); track product.id) { <app-product-card [product]="product" /> } @empty { <div class="empty-state"><span>⌕</span><h2>Chưa có sản phẩm phù hợp</h2><p>Thử thay đổi từ khóa hoặc bộ lọc.</p><button class="button button-secondary" type="button" (click)="resetFilters()">Xóa bộ lọc</button></div> } }
        </div>
      </div>
    </section>
  `,
})
export class ProductsComponent implements OnInit {
  readonly catalog = inject(CatalogService); private readonly route = inject(ActivatedRoute);
  readonly filterOpen = signal(false);
  query = ''; category = ''; priceRange = ''; sort = 'newest';
  ngOnInit(): void { this.query = this.route.snapshot.queryParamMap.get('q') ?? ''; this.catalog.load(); }
  filtered() {
    let result = this.catalog.products().filter(product => {
      const term = this.query.trim().toLowerCase(); const price = product.minPrice;
      const matchesQuery = !term || `${product.name} ${product.slug} ${product.shortDescription ?? ''}`.toLowerCase().includes(term);
      const matchesCategory = !this.category || product.category.slug === this.category;
      const matchesPrice = !this.priceRange || price == null || (this.priceRange === '300' ? price < 300000 : this.priceRange === '500' ? price >= 300000 && price <= 500000 : price > 500000);
      return matchesQuery && matchesCategory && matchesPrice;
    });
    if (this.sort === 'price-asc') result = [...result].sort((a, b) => (a.minPrice ?? Number.MAX_VALUE) - (b.minPrice ?? Number.MAX_VALUE));
    if (this.sort === 'price-desc') result = [...result].sort((a, b) => (b.minPrice ?? 0) - (a.minPrice ?? 0));
    return result;
  }
  resetFilters(): void { this.query = ''; this.category = ''; this.priceRange = ''; }
}
