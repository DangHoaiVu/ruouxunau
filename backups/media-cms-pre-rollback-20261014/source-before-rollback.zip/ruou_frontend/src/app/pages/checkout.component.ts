import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-checkout', imports: [RouterLink],
  template: `<section class="checkout-page section container"><div class="empty-state"><span aria-hidden="true">⌛</span><p class="eyebrow">Khóa an toàn</p><h1>Thanh toán chưa được kích hoạt</h1><p>Luồng COD, chuyển khoản, VNPay và vận chuyển chỉ mở sau khi backend hoàn thành giữ tồn, state machine đơn hàng, xác thực IPN và adapter đơn vị vận chuyển.</p><a class="button button-secondary" routerLink="/gio-hang">Quay lại giỏ hàng</a></div></section>`,
})
export class CheckoutComponent {}
