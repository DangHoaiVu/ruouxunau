import { Component, OnInit, inject, signal } from '@angular/core';
import { ActivatedRoute, RouterLink } from '@angular/router';
import { apiErrorMessage } from '../core/api-error';
import { ContentService } from '../core/content.service';
import { Story } from '../core/models';
import { StoreService } from '../core/store.service';

@Component({
  selector: 'app-article', imports: [RouterLink],
  template: `
    @if (loading()) { <section class="section loading-state">Đang tải bài viết…</section> }
    @else if (story(); as article) { <article class="article-page"><header class="article-header container"><a class="back-link" routerLink="/cau-chuyen">← Tất cả câu chuyện</a><p class="eyebrow">{{ article.category.name }}</p><h1>{{ article.title }}</h1><p class="article-deck">{{ article.excerpt }}</p><div class="article-meta"><span>{{ article.authorName }}</span><span>{{ formatDate(article.publishedAt) }}</span></div></header>@if (article.featuredMedia?.url) { <figure class="article-cover"><img [src]="article.featuredMedia!.url" [alt]="article.featuredMedia!.altText || article.title" /></figure> }<div class="article-layout container"><aside><strong>Chia sẻ bài viết</strong><button type="button" (click)="share()">Sao chép liên kết</button></aside><div class="article-content">@for (paragraph of paragraphs(article.content); track $index) { <p [class.drop-cap]="$first">{{ paragraph }}</p> }<div class="responsible">Thưởng thức có trách nhiệm. Không chia sẻ đồ uống có cồn cho người dưới 18 tuổi và không lái xe sau khi uống.</div></div></div></article> }
    @else { <section class="section empty-state"><h1>Không tìm thấy bài viết</h1><p>{{ error() }}</p><a class="button button-primary" routerLink="/cau-chuyen">Về tạp chí</a></section> }
  `,
})
export class ArticleComponent implements OnInit {
  readonly store = inject(StoreService); private readonly content = inject(ContentService); private readonly route = inject(ActivatedRoute);
  readonly story = signal<Story | null>(null); readonly loading = signal(true); readonly error = signal('');
  ngOnInit(): void { this.content.detail(this.route.snapshot.paramMap.get('slug') ?? '').subscribe({ next: story => { this.story.set(story); this.loading.set(false); }, error: error => { this.error.set(apiErrorMessage(error, 'Bài viết không tồn tại hoặc chưa được xuất bản.')); this.loading.set(false); } }); }
  paragraphs(content?: string): string[] { return (content ?? '').split(/\n\s*\n/).map(item => item.trim()).filter(Boolean); }
  formatDate(value: string): string { return new Intl.DateTimeFormat('vi-VN', { dateStyle: 'long' }).format(new Date(value)); }
  async share(): Promise<void> { try { await navigator.clipboard.writeText(location.href); this.store.notify('Đã sao chép liên kết bài viết'); } catch { this.store.notify('Không thể sao chép tự động. Hãy sao chép URL trên thanh địa chỉ.'); } }
}
