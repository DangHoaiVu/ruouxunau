import { Component, OnInit, inject, signal } from '@angular/core';
import { DomSanitizer, SafeResourceUrl } from '@angular/platform-browser';
import { SiteContentService } from '../core/site-content.service';

@Component({
  selector: 'app-contact',
  template: `
    <section class="page-hero compact contact-hero"><div class="container"><p class="eyebrow light">Kết nối với Xứ Nẫu</p><h1>Ghé thăm,<br /><em>trò chuyện cùng chúng tôi.</em></h1></div></section>
    <section class="section container contact-grid">
      <div><p class="eyebrow">Thông tin liên hệ</p><h2>Chúng tôi luôn sẵn lòng lắng nghe.</h2>
        @if (site.loading()) { <div class="loading-state">Đang tải thông tin…</div> }
        @else if (site.settings(); as settings) { <div class="contact-lines">
          @if (settings.phone) { <div><small>Điện thoại</small><a [href]="'tel:' + settings.phone">{{ settings.phone }}</a></div> }
          @if (settings.email) { <div><small>Email</small><a [href]="'mailto:' + settings.email">{{ settings.email }}</a></div> }
          @if (settings.address) { <div><small>Địa chỉ</small><span>{{ settings.address }}</span></div> }
          @if (settings.businessHours) { <div><small>Giờ làm việc</small><span>{{ settings.businessHours }}</span></div> }
        </div>@if (settings.directionsUrl) { <a class="button button-secondary" [href]="settings.directionsUrl" target="_blank" rel="noopener noreferrer">Mở chỉ đường ↗</a> } }
        @else { <div class="empty-state compact"><h3>Thông tin đang được cập nhật</h3><p>Quản trị viên chưa công bố thông tin liên hệ chính thức.</p></div> }
      </div>
      <div class="map-panel">
        @if (site.settings()?.embedUrl && mapLoaded()) { <iframe [src]="safeEmbedUrl()" title="Bản đồ vị trí Rượu Xứ Nẫu" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe> }
        @else if (site.settings()?.embedUrl) { <div class="map-consent"><span aria-hidden="true">⌖</span><h3>Xem vị trí trên Google Maps</h3><p>Bản đồ chỉ được tải sau khi bạn đồng ý để giảm dữ liệu bên thứ ba và tăng tốc trang.</p><button class="button button-primary" type="button" (click)="mapLoaded.set(true)">Tải bản đồ</button></div> }
        @else { <div class="map-consent"><span aria-hidden="true">⌖</span><h3>Bản đồ chưa được công bố</h3><p>URL bản đồ chính thức sẽ được cấu hình trong trang quản trị.</p></div> }
      </div>
    </section>
  `,
})
export class ContactComponent implements OnInit {
  readonly site = inject(SiteContentService); readonly mapLoaded = signal(false); private readonly sanitizer = inject(DomSanitizer);
  ngOnInit(): void { if (!this.site.settings()) this.site.load(); }
  safeEmbedUrl(): SafeResourceUrl { return this.sanitizer.bypassSecurityTrustResourceUrl(this.site.settings()?.embedUrl ?? ''); }
}
