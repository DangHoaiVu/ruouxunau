import { Component, inject } from '@angular/core';
import { RouterLink } from '@angular/router';
import { StoreService } from '../core/store.service';

@Component({
  selector: 'app-cart', imports: [RouterLink],
  template: `
    <section class="page-hero mini"><div class="container"><p class="eyebrow light">Đơn hàng của bạn</p><h1>Giỏ hàng</h1></div></section>
    <section class="section container cart-layout"><div class="cart-list"><div class="cart-title"><h2>Sản phẩm <span>({{ store.cartCount() }})</span></h2><a routerLink="/san-pham">Tiếp tục xem sản phẩm →</a></div>
      @for (item of store.cart(); track item.variant.id) { <article class="cart-item">@if (item.product.primaryImageUrl) { <img [src]="item.product.primaryImageUrl" [alt]="item.product.name" /> }<div class="cart-item-info"><p class="eyebrow">{{ item.product.category.name }}</p><h3>{{ item.product.name }}</h3><small>{{ item.variant.volumeMl }}ml · {{ item.variant.alcoholPercent }}% vol</small><button type="button" (click)="store.removeFromCart(item.variant.id)">Xóa</button></div><div class="quantity"><button type="button" (click)="store.updateQuantity(item.variant.id, item.quantity - 1)">−</button><span>{{ item.quantity }}</span><button type="button" (click)="store.updateQuantity(item.variant.id, item.quantity + 1)">+</button></div><strong class="line-price">{{ store.formatPrice(item.variant.price * item.quantity) }}</strong></article> }
      @empty { <div class="empty-state"><h2>Giỏ hàng chưa được mở</h2><p>Giỏ hàng server-side sẽ được kích hoạt sau khi API tồn kho và giữ tồn hoàn tất. Không có dữ liệu mẫu hoặc localStorage được sử dụng.</p><a class="button button-primary" routerLink="/san-pham">Xem bộ sưu tập</a></div> }
    </div>@if (store.cart().length) { <aside class="order-summary"><h2>Tóm tắt</h2><dl><div class="summary-total"><dt>Tạm tính</dt><dd>{{ store.formatPrice(store.subtotal()) }}</dd></div></dl><a class="button button-primary full" routerLink="/thanh-toan">Tiến hành thanh toán</a></aside> }</section>
  `,
})
export class CartComponent { readonly store = inject(StoreService); }
