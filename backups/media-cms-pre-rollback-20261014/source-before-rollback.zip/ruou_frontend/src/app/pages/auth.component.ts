import { Component, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { apiErrorMessage } from '../core/api-error';
import { AuthService } from '../core/auth.service';
import { StoreService } from '../core/store.service';

@Component({
  selector: 'app-auth', imports: [FormsModule, RouterLink],
  template: `
    <section class="auth-page"><div class="auth-visual"><div><p class="eyebrow light">Thành viên Xứ Nẫu</p><h1>Mỗi chai rượu,<br /><em>một câu chuyện.</em></h1><p>Đăng nhập để mua hàng, theo dõi đơn và lưu những hương vị bạn yêu thích.</p></div></div>
      <div class="auth-form-wrap"><form class="auth-form" #authForm="ngForm" (ngSubmit)="submit()" novalidate><a class="back-link" routerLink="/">← Về trang chủ</a>
        @if (mode() === 'login') { <p class="eyebrow">Chào mừng trở lại</p><h2>Đăng nhập</h2><p class="muted">Phiên đăng nhập được xác thực bởi hệ thống Spring Boot.</p> }
        @else if (mode() === 'register') { <p class="eyebrow">Thành viên mới</p><h2>Tạo tài khoản</h2><p class="muted">Thông tin được lưu an toàn trong cơ sở dữ liệu của hệ thống.</p><label>Họ và tên<input name="name" [(ngModel)]="name" autocomplete="name" required maxlength="150" placeholder="Nguyễn Văn A" /></label> }
        @else { <p class="eyebrow">Khôi phục truy cập</p><h2>Quên mật khẩu</h2><p class="muted">Nếu email tồn tại, hệ thống sẽ gửi hướng dẫn đặt lại mật khẩu.</p> }

        <label>Email<input type="email" name="email" [(ngModel)]="email" autocomplete="email" required maxlength="254" placeholder="ban@example.com" /></label>
        @if (mode() !== 'forgot') {
          <label>Mật khẩu<span><input [type]="showPassword() ? 'text' : 'password'" name="password" [(ngModel)]="password" [attr.autocomplete]="mode() === 'login' ? 'current-password' : 'new-password'" required minlength="12" maxlength="72" aria-describedby="password-help" placeholder="12–72 ký tự" /><button type="button" (click)="showPassword.set(!showPassword())">{{ showPassword() ? 'Ẩn' : 'Hiện' }}</button></span></label>
          @if (mode() === 'register') { <small id="password-help" class="field-help">Mật khẩu cần 12–72 byte, có chữ hoa, chữ thường và chữ số.</small><label>Xác nhận mật khẩu<input type="password" name="confirmPassword" [(ngModel)]="confirmPassword" autocomplete="new-password" required /></label><label class="check-row legal-check"><input type="checkbox" name="ageConfirmed" [(ngModel)]="ageConfirmed" required /> Tôi xác nhận đã đủ 18 tuổi và đồng ý với điều khoản sử dụng.</label> }
        }
        @if (mode() === 'login') { <div class="form-options"><span>Phiên được duy trì bằng cookie bảo mật.</span><button type="button" class="link-button" (click)="switchMode('forgot')">Quên mật khẩu?</button></div> }
        @if (error()) { <p class="form-error" role="alert">{{ error() }}</p> }
        @if (success()) { <p class="form-success" role="status">{{ success() }}</p> }
        <button class="button button-primary full" type="submit" [disabled]="auth.busy() || !authForm.valid">{{ auth.busy() ? 'Đang xử lý…' : mode() === 'login' ? 'Đăng nhập' : mode() === 'register' ? 'Tạo tài khoản' : 'Gửi yêu cầu' }}</button>
        <p class="auth-switch">@if (mode() === 'login') { Chưa có tài khoản? <button type="button" (click)="switchMode('register')">Đăng ký ngay</button> } @else { Đã có tài khoản? <button type="button" (click)="switchMode('login')">Quay lại đăng nhập</button> }</p>
      </form></div>
    </section>
  `,
})
export class AuthComponent {
  readonly auth = inject(AuthService); private readonly store = inject(StoreService); private readonly router = inject(Router); private readonly route = inject(ActivatedRoute);
  readonly showPassword = signal(false); readonly mode = signal<'login' | 'register' | 'forgot'>('login'); readonly error = signal(''); readonly success = signal('');
  name = ''; email = ''; password = ''; confirmPassword = ''; ageConfirmed = false;

  switchMode(mode: 'login' | 'register' | 'forgot'): void { this.mode.set(mode); this.error.set(''); this.success.set(''); }

  submit(): void {
    this.error.set(''); this.success.set('');
    if (this.mode() === 'forgot') {
      this.auth.forgotPassword(this.email.trim()).subscribe({
        next: () => this.success.set('Nếu email tồn tại, hướng dẫn đặt lại mật khẩu đã được gửi.'),
        error: error => this.error.set(apiErrorMessage(error)),
      });
      return;
    }
    if (this.mode() === 'register') {
      if (this.password !== this.confirmPassword) { this.error.set('Mật khẩu xác nhận chưa khớp.'); return; }
      if (!this.validPassword(this.password)) { this.error.set('Mật khẩu cần 12–72 byte, có chữ hoa, chữ thường và chữ số.'); return; }
      this.auth.register(this.name.trim(), this.email.trim(), this.password, this.ageConfirmed).subscribe({
        next: () => this.finishAuthentication(), error: error => this.error.set(apiErrorMessage(error)),
      });
      return;
    }
    this.auth.login(this.email.trim(), this.password).subscribe({
      next: () => this.finishAuthentication(), error: error => this.error.set(apiErrorMessage(error)),
    });
  }

  private finishAuthentication(): void {
    const requested = this.route.snapshot.queryParamMap.get('returnUrl');
    const target = requested?.startsWith('/') && !requested.startsWith('//') ? requested : '/tai-khoan';
    this.store.notify(`Xin chào, ${this.auth.user()?.fullName}`);
    this.router.navigateByUrl(target);
  }

  private validPassword(password: string): boolean {
    const bytes = new TextEncoder().encode(password).length;
    return bytes >= 12 && bytes <= 72 && /[a-z]/.test(password) && /[A-Z]/.test(password) && /\d/.test(password);
  }
}
